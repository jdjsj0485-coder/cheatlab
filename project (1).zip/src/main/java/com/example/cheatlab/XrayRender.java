package com.example.cheatlab;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.Minecraft;
import net.minecraft.core.BlockPos;
import net.minecraft.client.renderer.LevelRenderer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RenderLevelStageEvent;
import net.minecraftforge.eventbus.api.EventPriority;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import org.joml.Matrix3f;
import org.joml.Matrix4f;

import java.util.List;

@Mod.EventBusSubscriber(modid = CheatLab.MODID, bus = Mod.EventBusSubscriber.Bus.FORGE, value = Dist.CLIENT)
public class XrayRender {
    @SubscribeEvent(priority = EventPriority.LOWEST)
    public static void onRender(RenderLevelStageEvent e) {
        if (e.getStage() != RenderLevelStageEvent.Stage.AFTER_TRANSLUCENT_BLOCKS) return;
        List<Xray.Hit> list = Xray.enabled ? Xray.hits() : List.of();
        List<BlockPos> route = GoTo.renderPath();
        if (list.isEmpty() && route.isEmpty() && GoTo.renderGoal() == null) return;
        try {
            Minecraft mc = Minecraft.getInstance();
            PoseStack ps = e.getPoseStack();
            Vec3 cam = e.getCamera().getPosition();
            MultiBufferSource.BufferSource buf = mc.renderBuffers().bufferSource();
            VertexConsumer vc = buf.getBuffer(XrayRenderType.LINES);
            ps.pushPose();
            ps.translate(-cam.x, -cam.y, -cam.z);
            for (Xray.Hit h : list) {
                float r = ((h.color() >> 16) & 255) / 255f;
                float g = ((h.color() >> 8) & 255) / 255f;
                float b = (h.color() & 255) / 255f;
                LevelRenderer.renderLineBox(ps, vc, new AABB(h.pos()).inflate(0.002), r, g, b, 1f);
            }
            // маршрут бота: красная линия от игрока до цели, цель - красная рамка
            if (route.size() > 0 && mc.player != null) {
                PoseStack.Pose pose = ps.last();
                Matrix4f mat = pose.pose();
                Matrix3f nor = pose.normal();
                Vec3 prev = mc.player.getPosition(e.getPartialTick()).add(0, 0.1, 0);
                int limit = Math.min(route.size(), 400);
                for (int i = 0; i < limit; i++) {
                    BlockPos n = route.get(i);
                    Vec3 cur = new Vec3(n.getX() + 0.5, n.getY() + 0.1, n.getZ() + 0.5);
                    Vec3 d = cur.subtract(prev);
                    double len = d.length();
                    if (len > 1e-4) {
                        float nx = (float) (d.x / len), ny = (float) (d.y / len), nz = (float) (d.z / len);
                        vc.vertex(mat, (float) prev.x, (float) prev.y, (float) prev.z)
                                .color(1f, 0.1f, 0.1f, 1f).normal(nor, nx, ny, nz).endVertex();
                        vc.vertex(mat, (float) cur.x, (float) cur.y, (float) cur.z)
                                .color(1f, 0.1f, 0.1f, 1f).normal(nor, nx, ny, nz).endVertex();
                    }
                    prev = cur;
                }
            }
            BlockPos g = GoTo.renderGoal();
            if (g != null) {
                LevelRenderer.renderLineBox(ps, vc, new AABB(g).inflate(0.05), 1f, 0.1f, 0.1f, 1f);
            }
            ps.popPose();
            buf.endBatch(XrayRenderType.LINES);
        } catch (Throwable t) {
            Modules.error("xray-render", t);
        }
    }
}
