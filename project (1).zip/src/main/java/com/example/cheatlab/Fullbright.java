package com.example.cheatlab;

import net.minecraft.client.Minecraft;
import net.minecraft.client.OptionInstance;

import java.lang.reflect.Field;
import java.lang.reflect.Modifier;

/**
 * Ночное зрение без зелья: поднимаем клиентскую яркость (gamma) выше обычного максимума.
 * Это чисто клиентская настройка, эффект на игроке не выдаётся и на сервер ничего не уходит.
 * Значение в OptionInstance проверяется на диапазон 0..1, поэтому записываем его напрямую через рефлексию.
 */
public final class Fullbright {
    private static final double LEVEL = 16.0;
    private static Field valueField;
    private static Double saved;

    private Fullbright() {}

    private static Field find(OptionInstance<?> opt) throws Exception {
        Object cur = opt.get();
        for (Field f : OptionInstance.class.getDeclaredFields()) {
            if (f.getType() != Object.class) continue;
            int m = f.getModifiers();
            if (Modifier.isStatic(m) || Modifier.isFinal(m)) continue;
            f.setAccessible(true);
            if (f.get(opt) == cur) return f;
        }
        return null;
    }

    private static void write(double v) throws Exception {
        OptionInstance<Double> g = Minecraft.getInstance().options.gamma();
        if (valueField == null) valueField = find(g);
        if (valueField == null) throw new IllegalStateException("brightness option field not found");
        valueField.set(g, Double.valueOf(v));
    }

    public static void enable() {
        try {
            OptionInstance<Double> g = Minecraft.getInstance().options.gamma();
            if (saved == null) {
                double cur = g.get();
                saved = cur <= 1.0 ? cur : 1.0;
            }
            write(LEVEL);
        } catch (Throwable t) {
            Modules.error("night", t);
        }
    }

    /** Вызывается каждый тик: если яркость сбросили (например, в настройках), возвращаем. */
    public static void ensure() {
        try {
            OptionInstance<Double> g = Minecraft.getInstance().options.gamma();
            if (saved == null || g.get() < LEVEL - 0.5) enable();
        } catch (Throwable t) {
            Modules.error("night", t);
        }
    }

    /** Вернуть обычную яркость. */
    public static void disable() {
        try {
            if (saved != null) write(saved);
        } catch (Throwable t) {
            Modules.error("night", t);
        }
        saved = null;
    }
}
