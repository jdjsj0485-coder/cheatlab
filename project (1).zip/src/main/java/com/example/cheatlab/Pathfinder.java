package com.example.cheatlab;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.tags.FluidTags;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.FallingBlock;
import net.minecraft.world.level.block.state.BlockState;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.PriorityQueue;

/**
 * A*-поиск пути по загруженному миру.
 * Ходит, прыгает на 1 блок вверх, спрыгивает до 3 блоков вниз. Обходит лаву, огонь, паутину, магму,
 * глубокие обрывы и незагруженные чанки. Воду (реки, океаны) обходит по суше, а если по суше не пройти,
 * плывёт по поверхности (голова над водой, чтобы не тонуть).
 * В режиме dig может прорывать блоки (но не вскрывает жидкости и не рушит песок/гравий на голову).
 */
public final class Pathfinder {
    public record Result(List<BlockPos> nodes, boolean complete) {}

    private record Move(BlockPos pos, double cost) {}

    private static final class Node {
        final BlockPos pos;
        final Node parent;
        final double g;
        final double f;

        Node(BlockPos pos, Node parent, double g, double f) {
            this.pos = pos;
            this.parent = parent;
            this.g = g;
            this.f = f;
        }
    }

    public static final double INF = Double.POSITIVE_INFINITY;
    /** Стоимость клетки в воде. Большая, чтобы океан обходился по суше, пока это вообще возможно. */
    private static final double WATER_COST = 8.0;
    private static final double H_WEIGHT = 1.4;
    private static final int MAX_EXPANSIONS = 20000;
    private static final Direction[] HORIZ = {Direction.NORTH, Direction.SOUTH, Direction.EAST, Direction.WEST};

    private Pathfinder() {}

    private static double h(BlockPos a, int gx, Integer gy, int gz) {
        double v = Math.abs(a.getX() - gx) + Math.abs(a.getZ() - gz);
        if (gy != null) v += Math.abs(a.getY() - gy) * 0.5;
        return v * H_WEIGHT;
    }

    private static boolean isGoal(BlockPos p, int gx, Integer gy, int gz) {
        return p.getX() == gx && p.getZ() == gz && (gy == null || p.getY() == gy);
    }

    /** gy == null: цель только по X/Z (высота не важна, идём по поверхности). */
    public static Result find(Level level, BlockPos start, int gx, Integer gy, int gz, boolean dig) {
        PriorityQueue<Node> open = new PriorityQueue<>(Comparator.comparingDouble((Node n) -> n.f));
        Map<Long, Double> best = new HashMap<>();
        Node s = new Node(start, null, 0.0, h(start, gx, gy, gz));
        open.add(s);
        best.put(start.asLong(), 0.0);

        Node closest = s;
        double closestH = h(start, gx, gy, gz);
        int expansions = 0;
        List<Move> moves = new ArrayList<>();

        while (!open.isEmpty() && expansions < MAX_EXPANSIONS) {
            Node cur = open.poll();
            Double bg = best.get(cur.pos.asLong());
            if (bg != null && cur.g > bg + 1e-9) continue;
            if (isGoal(cur.pos, gx, gy, gz)) return new Result(build(cur), true);

            double hh = h(cur.pos, gx, gy, gz);
            if (hh < closestH) {
                closestH = hh;
                closest = cur;
            }
            expansions++;

            moves.clear();
            neighbors(level, cur.pos, dig, moves);
            for (Move m : moves) {
                double ng = cur.g + m.cost();
                Double old = best.get(m.pos().asLong());
                if (old == null || ng < old) {
                    best.put(m.pos().asLong(), ng);
                    open.add(new Node(m.pos(), cur, ng, ng + h(m.pos(), gx, gy, gz)));
                }
            }
        }
        return new Result(build(closest), false);
    }

    private static List<BlockPos> build(Node end) {
        List<BlockPos> list = new ArrayList<>();
        for (Node n = end; n != null; n = n.parent) list.add(n.pos);
        Collections.reverse(list);
        return list;
    }

    private static void neighbors(Level level, BlockPos n, boolean dig, List<Move> out) {
        for (Direction d : HORIZ) {
            BlockPos m0 = n.relative(d);

            // 1) на том же уровне
            double flat = standCost(level, m0, dig);
            if (flat < INF) out.add(new Move(m0, 1.0 + flat + waterPen(level, m0)));

            // 2) шаг вверх на 1 блок
            BlockPos up = m0.above();
            double head = clearCost(level, n.above(2), dig);
            if (head < INF) {
                double su = standCost(level, up, dig);
                if (su < INF) out.add(new Move(up, 2.2 + head + su + waterPen(level, up)));
            }

            // 3) спуск вниз (до 3 блоков), глубже - это обрыв и мы его обходим
            double a = clearCost(level, m0, dig) + clearCost(level, m0.above(), dig);
            if (a < INF) {
                double acc = a;
                for (int k = 1; k <= 3; k++) {
                    BlockPos c = m0.below(k);
                    double cc = clearCost(level, c, dig);
                    if (cc == INF) break;
                    acc += cc;
                    if (standOk(level, c)) {
                        out.add(new Move(c, 1.5 + k + acc + waterPen(level, c)));
                        break;
                    }
                }
            }

            // 4) плыть по поверхности воды (клетка на том же уровне, на 1 ниже или на 1 выше)
            for (int dy = 0; dy >= -1; dy--) {
                BlockPos c = m0.offset(0, dy, 0);
                double sw = swimCost(level, c);
                if (sw < INF) out.add(new Move(c, sw + (dy != 0 ? 0.5 : 0.0)));
            }
            BlockPos hi = m0.above();
            double swHi = swimCost(level, hi);
            if (swHi < INF) out.add(new Move(hi, swHi + 0.5));
        }

        // 5) копать вертикальную шахту вниз
        if (dig) {
            BlockPos c = n.below();
            double sc = standCost(level, c, true);
            if (sc < INF) out.add(new Move(c, 2.5 + sc));
        }
    }

    private static double waterPen(Level level, BlockPos feet) {
        return isWater(level, feet) ? WATER_COST : 0.0;
    }

    private static boolean isWater(Level level, BlockPos pos) {
        return level.getFluidState(pos).is(FluidTags.WATER);
    }

    private static boolean inBounds(Level level, BlockPos feet) {
        return feet.getY() > level.getMinBuildHeight() + 1 && feet.getY() < level.getMaxBuildHeight() - 2
                && level.hasChunkAt(feet);
    }

    /** Можно ли встать в эту клетку (без учёта расчистки). */
    private static boolean standOk(Level level, BlockPos feet) {
        if (!inBounds(level, feet)) return false;
        if (!solidFloor(level, feet.below())) return false;
        if (isWater(level, feet.above())) return false; // голова под водой - утонем
        return !lavaNear(level, feet) && !lavaNear(level, feet.above());
    }

    /** Стоимость того, чтобы встать в клетку: расчистка ног и головы. INF если нельзя. */
    private static double standCost(Level level, BlockPos feet, boolean dig) {
        if (!standOk(level, feet)) return INF;
        double a = clearCost(level, feet, dig);
        double b = clearCost(level, feet.above(), dig);
        return a + b;
    }

    /** Поверхность воды: ноги в воде, над головой воздух. Тонуть нельзя, поэтому только верхний слой. */
    private static double swimCost(Level level, BlockPos feet) {
        if (!inBounds(level, feet)) return INF;
        if (!isWater(level, feet)) return INF;
        BlockPos headPos = feet.above();
        if (!level.hasChunkAt(headPos) || isWater(level, headPos)) return INF;
        if (!passable(level, headPos)) return INF;
        if (lavaNear(level, feet)) return INF;
        return WATER_COST;
    }

    /** 0 - проходимо, число - цена прокопки, INF - нельзя. */
    public static double clearCost(Level level, BlockPos pos, boolean dig) {
        if (!level.hasChunkAt(pos)) return INF;
        if (passable(level, pos)) return 0.0;
        if (!dig) return INF;
        BlockState s = level.getBlockState(pos);
        if (s.getCollisionShape(level, pos).isEmpty()) return INF; // огонь, паутина, лава и т.п.
        return breakCost(level, pos, s);
    }

    private static double breakCost(Level level, BlockPos pos, BlockState s) {
        float hard = s.getDestroySpeed(level, pos);
        if (hard < 0) return INF;                       // бедрок и прочее неразрушимое
        if (!s.getFluidState().isEmpty()) return INF;
        if (s.hasBlockEntity()) return INF;              // сундуки, печи, спавнеры - не трогаем
        for (Direction d : Direction.values()) {
            if (!level.getFluidState(pos.relative(d)).isEmpty()) return INF; // не вскрываем воду и лаву
        }
        if (level.getBlockState(pos.above()).getBlock() instanceof FallingBlock) return INF; // песок/гравий сверху
        return 3.0 + Math.min(hard, 10.0f) * 1.5;
    }

    public static boolean passable(Level level, BlockPos pos) {
        if (!level.hasChunkAt(pos)) return false;
        BlockState s = level.getBlockState(pos);
        if (!s.getCollisionShape(level, pos).isEmpty()) return false;
        if (s.getFluidState().is(FluidTags.LAVA)) return false;
        return !(s.is(Blocks.FIRE) || s.is(Blocks.SOUL_FIRE) || s.is(Blocks.COBWEB)
                || s.is(Blocks.SWEET_BERRY_BUSH) || s.is(Blocks.POWDER_SNOW) || s.is(Blocks.WITHER_ROSE));
    }

    private static boolean solidFloor(Level level, BlockPos pos) {
        if (!level.hasChunkAt(pos)) return false;
        BlockState s = level.getBlockState(pos);
        if (s.getCollisionShape(level, pos).isEmpty()) return false;
        return !(s.is(Blocks.MAGMA_BLOCK) || s.is(Blocks.CACTUS) || s.is(Blocks.CAMPFIRE) || s.is(Blocks.SOUL_CAMPFIRE));
    }

    private static boolean lavaNear(Level level, BlockPos pos) {
        if (level.getFluidState(pos).is(FluidTags.LAVA)) return true;
        for (Direction d : Direction.values()) {
            if (level.getFluidState(pos.relative(d)).is(FluidTags.LAVA)) return true;
        }
        return false;
    }
}
