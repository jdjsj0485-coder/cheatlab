package com.example.cheatlab;

import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;

import java.util.ArrayList;
import java.util.List;

/**
 * Бот идёт к координатам: /cheatlab walk x z  или  /cheatlab walk x y z.
 * Без высоты: идёт по поверхности, обходит воду, если нельзя обойти - плывёт.
 * С высотой: ещё и прокапывается до этой высоты.
 * Путь строит Pathfinder и пересчитывает по ходу (по мере загрузки чанков).
 */
public final class GoTo {
    private static final int MAX_REPLANS = 400;

    private static boolean active;
    private static int gx, gz;
    private static Integer gy;
    private static boolean dig;
    private static List<BlockPos> path = new ArrayList<>();
    private static int idx;
    private static int sinceProgress;
    private static int replans;

    private GoTo() {}

    public static boolean active() { return active; }

    /** Клетка цели для красной рамки (если она известна). */
    public static BlockPos renderGoal() {
        if (!active) return null;
        if (gy != null) return new BlockPos(gx, gy, gz);
        if (!path.isEmpty()) {
            BlockPos last = path.get(path.size() - 1);
            if (last.getX() == gx && last.getZ() == gz) return last;
        }
        return null;
    }

    /** Оставшаяся часть маршрута (для красной линии). */
    public static List<BlockPos> renderPath() {
        if (!active || path.isEmpty()) return List.of();
        int from = Math.min(idx, path.size());
        return new ArrayList<>(path.subList(from, path.size()));
    }

    public static void start(int x, Integer y, int z) {
        Minecraft mc = Minecraft.getInstance();
        LocalPlayer p = mc.player;
        if (p == null || mc.level == null) return;
        if (Modules.fly) {
            Modules.say("[CheatLab] Turn Fly off first.");
            return;
        }
        if (y != null && (y < mc.level.getMinBuildHeight() || y >= mc.level.getMaxBuildHeight())) {
            Modules.say("[CheatLab] Height must be between " + mc.level.getMinBuildHeight()
                    + " and " + (mc.level.getMaxBuildHeight() - 1) + ".");
            return;
        }
        if (AutoMine.enabled) AutoMine.stop("[CheatLab] Auto-mine stopped.");
        gx = x;
        gz = z;
        gy = y;
        dig = y != null;
        active = true;
        replans = 0;
        sinceProgress = 0;
        if (dig) {
            Modules.say("[CheatLab] Walking to " + x + " " + y + " " + z + " (will dig to that height). Stop: /cheatlab stop");
        } else {
            Modules.say("[CheatLab] Walking to " + x + " " + z + ". Stop: /cheatlab stop");
        }
        plan(mc, p);
    }

    public static void stop(String message) {
        boolean was = active;
        active = false;
        path = new ArrayList<>();
        idx = 0;
        Minecraft mc = Minecraft.getInstance();
        if (mc.options != null) {
            mc.options.keyUp.setDown(false);
            mc.options.keyJump.setDown(false);
        }
        if (was && message != null) Modules.say(message);
    }

    private static void plan(Minecraft mc, LocalPlayer p) {
        Level level = mc.level;
        Pathfinder.Result r = Pathfinder.find(level, p.blockPosition(), gx, gy, gz, dig);
        idx = 1; // узел 0 - это текущая клетка
        sinceProgress = 0;
        if (r.nodes().size() <= 1) {
            path = new ArrayList<>(r.nodes());
            if (reached(p.blockPosition())) {
                stop("[CheatLab] Arrived.");
            } else {
                BlockPos f = p.blockPosition();
                int left = Math.abs(f.getX() - gx) + Math.abs(f.getZ() - gz) + (gy != null ? Math.abs(f.getY() - gy) : 0);
                stop("[CheatLab] No further path (about " + left + " blocks left). Blocked by lava, a wall, a cliff or unloaded terrain.");
            }
            return;
        }
        path = new ArrayList<>(r.nodes());
        if (!r.complete() && replans == 0) {
            Modules.say("[CheatLab] Full route not known yet, moving to the closest safe point and re-planning.");
        }
    }

    private static boolean reached(BlockPos feet) {
        if (gy == null) {
            return Math.abs(feet.getX() - gx) + Math.abs(feet.getZ() - gz) <= 1;
        }
        return feet.getX() == gx && feet.getZ() == gz && feet.getY() == gy;
    }

    /** Совпадает ли клетка игрока с узлом пути. В воде игрок качается на ±1 по высоте, это считаем тем же узлом. */
    private static boolean matches(LocalPlayer p, BlockPos feet, BlockPos node) {
        if (feet.getX() != node.getX() || feet.getZ() != node.getZ()) return false;
        int dy = Math.abs(feet.getY() - node.getY());
        return dy == 0 || (dy == 1 && p.isInWater());
    }

    /** Какие клетки надо освободить, чтобы пройти из feet в next. */
    private static List<BlockPos> cellsToClear(BlockPos feet, BlockPos next) {
        List<BlockPos> list = new ArrayList<>(4);
        int top = next.getY() > feet.getY() ? next.getY() + 1 : Math.max(next.getY() + 1, feet.getY() + 1);
        for (int yy = next.getY(); yy <= top; yy++) {
            list.add(new BlockPos(next.getX(), yy, next.getZ()));
        }
        if (next.getY() > feet.getY()) list.add(feet.above(2)); // место над головой для прыжка
        return list;
    }

    private static void selectBestTool(LocalPlayer p, BlockState state) {
        Inventory inv = p.getInventory();
        int best = inv.selected;
        float bestSpeed = inv.getItem(best).getDestroySpeed(state);
        for (int i = 0; i < 9; i++) {
            float s = inv.getItem(i).getDestroySpeed(state);
            if (s > bestSpeed) {
                bestSpeed = s;
                best = i;
            }
        }
        inv.selected = best;
    }

    public static void tick(Minecraft mc, LocalPlayer p) {
        if (!active) return;
        if (mc.level == null) return;
        if (mc.screen != null) {
            mc.options.keyUp.setDown(false);
            mc.options.keyJump.setDown(false);
            return;
        }
        if (Modules.fly || p.isPassenger()) {
            stop("[CheatLab] Go-to stopped (Fly or vehicle).");
            return;
        }
        if (p.getHealth() < 6.0f) {
            stop("[CheatLab] Go-to stopped: low health.");
            return;
        }
        if (p.isInLava() || p.isOnFire()) {
            stop("[CheatLab] Go-to stopped: danger (fire or lava).");
            return;
        }

        BlockPos feet = p.blockPosition();
        if (reached(feet)) {
            stop("[CheatLab] Arrived.");
            return;
        }

        if (idx >= path.size()) {
            if (++replans > MAX_REPLANS) {
                stop("[CheatLab] Go-to gave up after too many re-plans.");
                return;
            }
            plan(mc, p);
            return;
        }

        BlockPos next = path.get(idx);
        if (matches(p, feet, next)) {
            idx++;
            sinceProgress = 0;
            return;
        }
        // уже стоим на одном из следующих узлов
        for (int j = idx + 1; j < Math.min(path.size(), idx + 4); j++) {
            if (matches(p, feet, path.get(j))) {
                idx = j + 1;
                sinceProgress = 0;
                return;
            }
        }
        // сбились с маршрута или застряли
        if (feet.distSqr(next) > 25 || ++sinceProgress > 100) {
            if (++replans > MAX_REPLANS) {
                stop("[CheatLab] Go-to gave up (stuck).");
                return;
            }
            plan(mc, p);
            return;
        }

        // копаем, если на пути твёрдые блоки (только когда задана высота)
        if (dig && mc.gameMode != null) {
            for (BlockPos pos : cellsToClear(feet, next)) {
                BlockState st = mc.level.getBlockState(pos);
                if (st.isAir() || st.getCollisionShape(mc.level, pos).isEmpty()) continue;
                if (Pathfinder.clearCost(mc.level, pos, true) == Pathfinder.INF) {
                    // стало небезопасно копать (жидкость рядом, неразрушимый блок): ищем другой путь
                    if (++replans > MAX_REPLANS) {
                        stop("[CheatLab] Go-to gave up (cannot dig safely).");
                        return;
                    }
                    plan(mc, p);
                    return;
                }
                mc.options.keyUp.setDown(false);
                mc.options.keyJump.setDown(false);
                selectBestTool(p, st);
                AutoMine.mine(mc, p, pos);
                sinceProgress = 0;
                return;
            }
        }

        Vec3 want = Vec3.atBottomCenterOf(next);
        double dx = want.x - p.getX();
        double dz = want.z - p.getZ();
        double hd = Math.sqrt(dx * dx + dz * dz);
        if (hd > 0.08) {
            p.setYRot((float) Math.toDegrees(Math.atan2(-dx, dz)));
        }
        mc.options.keyUp.setDown(hd > 0.2);
        // в воде держим прыжок: плывём по поверхности и не тонем
        boolean jump = p.isInWater()
                || (p.onGround() && (next.getY() > feet.getY() || (p.horizontalCollision && hd > 0.3)));
        mc.options.keyJump.setDown(jump);
    }
}
