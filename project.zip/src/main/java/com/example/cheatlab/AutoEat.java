package com.example.cheatlab;

import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.food.FoodProperties;
import net.minecraft.world.inventory.ClickType;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

/**
 * Авто-еда: пока работают ходьба или авто-добыча, при голоде ест безопасную еду из инвентаря
 * (только еда без побочных эффектов; не трогает золотые яблоки, фрукт хоруса, подозрительное рагу).
 */
public final class AutoEat {
    private static boolean eating;
    private static boolean started;
    private static int ticks;
    private static int prevSelected;
    private static int swappedFrom = -1;
    private static int swappedHotbar = -1;
    private static boolean noFoodWarned;

    private AutoEat() {}

    /** Возвращает true, пока идёт еда: вызывающий код в этот тик должен стоять на месте. */
    public static boolean tick(Minecraft mc, LocalPlayer p) {
        if (!Modules.autoEat) {
            if (eating) finish(mc, p);
            return false;
        }
        if (mc.gameMode == null) return false;
        if (eating) return continueEating(mc, p);

        int food = p.getFoodData().getFoodLevel();
        if (food > 14) {
            noFoodWarned = false;
            return false;
        }
        int slot = findFood(p);
        if (slot < 0) {
            if (!noFoodWarned && food <= 8) {
                noFoodWarned = true;
                Modules.say("[CheatLab] Hungry, but there is no safe food in the inventory.");
            }
            return false;
        }
        begin(mc, p, slot);
        return true;
    }

    public static void abort() {
        if (!eating) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.player != null && mc.gameMode != null) finish(mc, mc.player);
        else eating = false;
    }

    private static boolean safeFood(ItemStack st) {
        if (st.isEmpty() || !st.isEdible()) return false;
        Item it = st.getItem();
        if (it == Items.CHORUS_FRUIT || it == Items.GOLDEN_APPLE || it == Items.ENCHANTED_GOLDEN_APPLE
                || it == Items.SUSPICIOUS_STEW) return false;
        FoodProperties fp = it.getFoodProperties();
        return fp != null && fp.getEffects().isEmpty();
    }

    private static int findFood(LocalPlayer p) {
        int best = -1;
        int bestNut = -1;
        for (int i = 0; i < p.getInventory().items.size(); i++) {
            ItemStack st = p.getInventory().items.get(i);
            if (!safeFood(st)) continue;
            FoodProperties fp = st.getItem().getFoodProperties();
            int nut = fp.getNutrition();
            if (nut > bestNut) {
                bestNut = nut;
                best = i;
            }
        }
        return best;
    }

    private static void begin(Minecraft mc, LocalPlayer p, int slot) {
        prevSelected = p.getInventory().selected;
        int hb;
        if (slot < 9) {
            hb = slot;
            swappedFrom = -1;
        } else {
            hb = (prevSelected + 1) % 9;
            for (int i = 0; i < 9; i++) {
                if (p.getInventory().items.get(i).isEmpty()) {
                    hb = i;
                    break;
                }
            }
            mc.gameMode.handleInventoryMouseClick(p.inventoryMenu.containerId, slot, hb, ClickType.SWAP, p);
            swappedFrom = slot;
            swappedHotbar = hb;
        }
        p.getInventory().selected = hb;
        eating = true;
        started = false;
        ticks = 0;
    }

    private static boolean continueEating(Minecraft mc, LocalPlayer p) {
        if (ticks++ == 0) p.setXRot(60f); // смотрим вниз, чтобы случайно не нажать на блок впереди
        mc.options.keyUse.setDown(true);
        mc.options.keyUp.setDown(false);
        mc.options.keyJump.setDown(false);
        mc.options.keySprint.setDown(false);
        if (p.isUsingItem()) started = true;
        boolean done = (started && !p.isUsingItem()) || ticks > 80 || p.getFoodData().getFoodLevel() >= 20;
        if (done) finish(mc, p);
        return true;
    }

    private static void finish(Minecraft mc, LocalPlayer p) {
        mc.options.keyUse.setDown(false);
        if (swappedFrom >= 0) {
            mc.gameMode.handleInventoryMouseClick(p.inventoryMenu.containerId, swappedFrom, swappedHotbar, ClickType.SWAP, p);
            swappedFrom = -1;
        }
        p.getInventory().selected = prevSelected;
        eating = false;
        started = false;
    }
}
