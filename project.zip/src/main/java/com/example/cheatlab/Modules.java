package com.example.cheatlab;

import com.mojang.logging.LogUtils;
import net.minecraft.client.Minecraft;
import net.minecraft.client.OptionInstance;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.network.chat.Component;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.player.Player;

import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.util.HashSet;
import java.util.Locale;
import java.util.Set;

public final class Modules {
    public static boolean fly, esp, boatFly, night;
    public static boolean autoForage = true; // если голоден и еды нет, бот сам ищет еду и возвращается к маршруту
    public static boolean autoEat = true; // есть еду из инвентаря во время ходьбы и авто-добычи
    public static boolean openMenu; // команда /cheatlab menu открывает меню на следующем тике
    public static double flySpeed = 0.6;   // блоков за тик
    public static double boatSpeed = 0.9;  // блоков за тик

    private static final Set<String> reported = new HashSet<>();

    private Modules() {}

    private static double round1(double v) { return Math.round(v * 10.0) / 10.0; }

    public static void toggleFly()  { fly = !fly;         msg("Fly", fly); }
    public static void toggleBoat() { boatFly = !boatFly; msg("Boat Fly", boatFly); }
    public static void toggleEsp()  {
        esp = !esp;
        msg("ESP", esp);
        if (!esp) clearGlow();
    }
    private static Field gammaValueField;
    private static double savedGamma = 0.5;
    private static boolean gammaApplied;

    public static void toggleNight() {
        night = !night;
        msg("Night vision", night);
        if (!night) restoreGamma();
    }

    /** Ночное зрение через яркость экрана (gamma). Никакого эффекта зелья: ничего не выдаётся игроку. */
    public static void nightTick(LocalPlayer p) {
        if (!night) {
            if (gammaApplied) restoreGamma();
            return;
        }
        try {
            Minecraft mc = Minecraft.getInstance();
            OptionInstance<Double> gamma = mc.options.gamma();
            Field f = gammaField();
            if (!gammaApplied) {
                savedGamma = gamma.get();
                gammaApplied = true;
            }
            if (Math.abs(gamma.get() - 16.0) > 1.0e-6) f.set(gamma, Double.valueOf(16.0));
        } catch (Throwable t) {
            night = false;
            gammaApplied = false;
            error("night-vision", t);
        }
    }

    private static void restoreGamma() {
        if (!gammaApplied) return;
        try {
            Minecraft mc = Minecraft.getInstance();
            gammaField().set(mc.options.gamma(), Double.valueOf(savedGamma));
        } catch (Throwable t) {
            error("night-restore", t);
        }
        gammaApplied = false;
    }

    private static Field gammaField() {
        if (gammaValueField == null) {
            for (Field f : OptionInstance.class.getDeclaredFields()) {
                int m = f.getModifiers();
                if (!Modifier.isStatic(m) && !Modifier.isFinal(m) && f.getType() == Object.class) {
                    f.setAccessible(true);
                    gammaValueField = f;
                    break;
                }
            }
        }
        if (gammaValueField == null) throw new IllegalStateException("gamma field not found");
        return gammaValueField;
    }

    public static void toggleAutoForage() { autoForage = !autoForage; msg("Auto-forage", autoForage); }

    public static boolean anythingRunning() {
        return AutoMine.enabled || GoTo.active() || Gatherer.active;
    }

    public static void stopAll() {
        if (AutoMine.enabled) AutoMine.stop(null);
        GoTo.stop(null);
        Gatherer.stop(null);
    }

    public static void toggleAutoEat() { autoEat = !autoEat; msg("Auto-eat", autoEat); }

    public static void toggleXray() {
        Xray.enabled = !Xray.enabled;
        Xray.markDirty();
        if (!Xray.enabled) Xray.clear();
        msg("X-Ray", Xray.enabled);
    }

    public static void setFlySpeed(double v) {
        flySpeed = Mth.clamp(round1(v), 0.1, 3.0);
    }

    public static void setBoatSpeed(double v) {
        boatSpeed = Mth.clamp(round1(v), 0.1, 5.0);
        showBoatSpeed();
    }

    public static void adjustFly(double d) {
        flySpeed = Mth.clamp(round1(flySpeed + d), 0.1, 3.0);
    }

    public static void adjustBoat(double d) {
        boatSpeed = Mth.clamp(round1(boatSpeed + d), 0.1, 5.0);
        showBoatSpeed();
    }

    public static void showBoatSpeed() {
        LocalPlayer p = Minecraft.getInstance().player;
        if (p != null) {
            p.displayClientMessage(Component.literal(String.format(Locale.ROOT,
                    "Boat speed: %.1f  (%.0f blocks/s)", boatSpeed, boatSpeed * 20)), true);
        }
    }

    public static void say(String text) {
        LocalPlayer p = Minecraft.getInstance().player;
        if (p != null) p.displayClientMessage(Component.literal(text), false);
    }

    private static void msg(String name, boolean on) {
        LocalPlayer p = Minecraft.getInstance().player;
        if (p != null) p.displayClientMessage(Component.literal(name + ": " + (on ? "ON" : "OFF")), true);
    }

    private static void clearGlow() {
        try {
            Minecraft mc = Minecraft.getInstance();
            if (mc.level == null) return;
            for (Player pl : mc.level.players()) pl.setGlowingTag(false);
        } catch (Throwable t) {
            error("clearGlow", t);
        }
    }

    /** Ошибка в одной функции не должна ломать остальные: пишем в лог и один раз в чат. */
    public static void error(String where, Throwable t) {
        if (!reported.add(where)) return;
        LogUtils.getLogger().error("[CheatLab] error in {}", where, t);
        try {
            LocalPlayer p = Minecraft.getInstance().player;
            if (p != null) {
                p.displayClientMessage(Component.literal("[CheatLab] error in " + where + ": " + t), false);
            }
        } catch (Throwable ignored) {
        }
    }
}
