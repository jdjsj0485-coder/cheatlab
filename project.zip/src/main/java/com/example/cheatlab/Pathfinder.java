package com.example.cheatlab;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.tags.FluidTags;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.PriorityQueue;

/**
 * A*-поиск пути по загруженному миру.
 * Обычный режим: ходит, прыгает на 1 блок вверх, спрыгивает до 3 блоков, обходит воду, лаву, огонь, обрывы.
 * Режим плавания (swim): дополнительно плывёт по поверхности воды так, чтобы голова оставалась над водой.
 * Блоки не ломает и двери не открывает.
 */
public final class Pathfinder {
    public record Result(List<BlockPos> nodes, boolean complete) {}

    private record Move(BlockPos pos, double cost) {}

    private static final class Node {
        final BlockPos pos;
        final Node parent;
        final double g;
        final double f;

        Node(BlockPos pos, Node parent, double g, double f) {
            this.pos = pos;
            this.parent = parent;
            this.g = g;
            this.f = f;
        }
    }

    private static final Direction[] HORIZ = {Direction.NORTH, Direction.SOUTH, Direction.EAST, Direction.WEST};
    private static final int MAX_EXPANSIONS = 15000;

    private Pathfinder() {}

    public static double h(BlockPos a, BlockPos b) {
        return Math.abs(a.getX() - b.getX()) + Math.abs(a.getZ() - b.getZ()) + Math.abs(a.getY() - b.getY()) * 0.5;
    }

    public static Result find(Level level, BlockPos start, BlockPos goal, boolean swim) {
        PriorityQueue<Node> open = new PriorityQueue<>(Comparator.comparingDouble((Node n) -> n.f));
        Map<Long, Double> best = new HashMap<>();
        Node s = new Node(start, null, 0.0, h(start, goal));
        open.add(s);
        best.put(start.asLong(), 0.0);

        Node closest = s;
        double closestH = h(start, goal);
        int expansions = 0;
        List<Move> moves = new ArrayList<>();

        while (!open.isEmpty() && expansions < MAX_EXPANSIONS) {
            Node cur = open.poll();
            Double bg = best.get(cur.pos.asLong());
            if (bg != null && cur.g > bg + 1e-9) continue;
            if (cur.pos.equals(goal)) return new Result(build(cur), true);

            double hh = h(cur.pos, goal);
            if (hh < closestH) {
                closestH = hh;
                closest = cur;
            }
            expansions++;

            moves.clear();
            neighbors(level, cur.pos, swim, moves);
            for (Move m : moves) {
                double ng = cur.g + m.cost();
                Double old = best.get(m.pos().asLong());
                if (old == null || ng < old) {
                    best.put(m.pos().asLong(), ng);
                    open.add(new Node(m.pos(), cur, ng, ng + h(m.pos(), goal)));
                }
            }
        }
        return new Result(build(closest), false);
    }

    private static List<BlockPos> build(Node end) {
        List<BlockPos> list = new ArrayList<>();
        for (Node n = end; n != null; n = n.parent) list.add(n.pos);
        Collections.reverse(list);
        return list;
    }

    private static void neighbors(Level level, BlockPos n, boolean swim, List<Move> out) {
        for (Direction d : HORIZ) {
            BlockPos m0 = n.relative(d);
            boolean added = false;
            if (standing(level, m0, swim)) {
                out.add(new Move(m0, 1.0));
                added = true;
            }
            if (swim && isSwim(level, m0)) {
                out.add(new Move(m0, 1.4));
                added = true;
            }
            if (added) continue;

            // шаг вверх на 1 блок (в том числе выход из воды на берег)
            BlockPos up = m0.above();
            if (passable(level, n.above(2), swim) && standing(level, up, swim)) {
                out.add(new Move(up, 2.2));
                continue;
            }
            // спрыгнуть вниз (до 3 блоков) на землю или в воду; глубже - это обрыв, обходим
            if (passable(level, m0, swim) && passable(level, m0.above(), swim)) {
                for (int k = 1; k <= 3; k++) {
                    BlockPos c = m0.below(k);
                    if (!passable(level, c, swim)) break;
                    if (standing(level, c, swim) || (swim && isSwim(level, c))) {
                        out.add(new Move(c, 1.5 + k));
                        break;
                    }
                }
            }
        }
    }

    /** Можно ли стоять в этой клетке (ноги), на твёрдой опоре. */
    public static boolean standing(Level level, BlockPos feet, boolean swim) {
        if (feet.getY() <= level.getMinBuildHeight() + 1 || feet.getY() >= level.getMaxBuildHeight() - 2) return false;
        if (!level.hasChunkAt(feet)) return false;
        if (!passable(level, feet, swim) || !passable(level, feet.above(), swim)) return false;
        if (!solidFloor(level, feet.below())) return false;
        return !lavaNear(level, feet) && !lavaNear(level, feet.above());
    }

    /** Клетка на поверхности воды: ноги в воде, голова над водой (дышать можно, урона нет). */
    public static boolean isSwim(Level level, BlockPos c) {
        if (c.getY() <= level.getMinBuildHeight() + 1 || c.getY() >= level.getMaxBuildHeight() - 2) return false;
        if (!level.hasChunkAt(c)) return false;
        if (!level.getFluidState(c).is(FluidTags.WATER)) return false;
        BlockPos head = c.above();
        if (level.getFluidState(head).is(FluidTags.WATER)) return false;
        if (!level.getBlockState(head).getCollisionShape(level, head).isEmpty()) return false;
        if (!level.getBlockState(c).getCollisionShape(level, c).isEmpty()) return false;
        return !lavaNear(level, c) && !lavaNear(level, head);
    }

    private static boolean passable(Level level, BlockPos pos, boolean swim) {
        if (!level.hasChunkAt(pos)) return false;
        BlockState s = level.getBlockState(pos);
        if (!s.getCollisionShape(level, pos).isEmpty()) return false;
        if (s.getFluidState().is(FluidTags.LAVA)) return false;
        if (!swim && s.getFluidState().is(FluidTags.WATER)) return false;
        return !(s.is(Blocks.FIRE) || s.is(Blocks.SOUL_FIRE) || s.is(Blocks.COBWEB)
                || s.is(Blocks.SWEET_BERRY_BUSH) || s.is(Blocks.POWDER_SNOW) || s.is(Blocks.WITHER_ROSE));
    }

    private static boolean solidFloor(Level level, BlockPos pos) {
        if (!level.hasChunkAt(pos)) return false;
        BlockState s = level.getBlockState(pos);
        if (s.getCollisionShape(level, pos).isEmpty()) return false;
        return !(s.is(Blocks.MAGMA_BLOCK) || s.is(Blocks.CACTUS) || s.is(Blocks.CAMPFIRE) || s.is(Blocks.SOUL_CAMPFIRE));
    }

    private static boolean lavaNear(Level level, BlockPos pos) {
        if (level.getFluidState(pos).is(FluidTags.LAVA)) return true;
        for (Direction d : Direction.values()) {
            if (level.getFluidState(pos.relative(d)).is(FluidTags.LAVA)) return true;
        }
        return false;
    }
}
