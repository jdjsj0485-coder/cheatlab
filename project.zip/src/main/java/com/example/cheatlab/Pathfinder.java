package com.example.cheatlab;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.tags.FluidTags;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.PriorityQueue;

/**
 * A*-поиск пути по загруженному миру. Ходит, прыгает на 1 блок вверх, спрыгивает до 3 блоков вниз.
 * Обходит лаву, огонь, паутину, магму, обрывы глубже 3 блоков и незагруженные чанки.
 * Блоки не ломает и двери не открывает.
 */
public final class Pathfinder {
    public record Result(List<BlockPos> nodes, boolean complete) {}

    private record Move(BlockPos pos, double cost) {}

    private static final class Node {
        final BlockPos pos;
        final Node parent;
        final double g;
        final double f;

        Node(BlockPos pos, Node parent, double g, double f) {
            this.pos = pos;
            this.parent = parent;
            this.g = g;
            this.f = f;
        }
    }

    private static final Direction[] HORIZ = {Direction.NORTH, Direction.SOUTH, Direction.EAST, Direction.WEST};
    private static final int MAX_EXPANSIONS = 15000;

    private Pathfinder() {}

    private static double h(BlockPos a, BlockPos b) {
        return Math.abs(a.getX() - b.getX()) + Math.abs(a.getZ() - b.getZ()) + Math.abs(a.getY() - b.getY()) * 0.5;
    }

    public static Result find(Level level, BlockPos start, BlockPos goal) {
        PriorityQueue<Node> open = new PriorityQueue<>(Comparator.comparingDouble((Node n) -> n.f));
        Map<Long, Double> best = new HashMap<>();
        Node s = new Node(start, null, 0.0, h(start, goal));
        open.add(s);
        best.put(start.asLong(), 0.0);

        Node closest = s;
        double closestH = h(start, goal);
        int expansions = 0;
        List<Move> moves = new ArrayList<>();

        while (!open.isEmpty() && expansions < MAX_EXPANSIONS) {
            Node cur = open.poll();
            Double bg = best.get(cur.pos.asLong());
            if (bg != null && cur.g > bg + 1e-9) continue;
            if (cur.pos.equals(goal)) return new Result(build(cur), true);

            double hh = h(cur.pos, goal);
            if (hh < closestH) {
                closestH = hh;
                closest = cur;
            }
            expansions++;

            moves.clear();
            neighbors(level, cur.pos, moves);
            for (Move m : moves) {
                double ng = cur.g + m.cost();
                Double old = best.get(m.pos().asLong());
                if (old == null || ng < old) {
                    best.put(m.pos().asLong(), ng);
                    open.add(new Node(m.pos(), cur, ng, ng + h(m.pos(), goal)));
                }
            }
        }
        return new Result(build(closest), false);
    }

    private static List<BlockPos> build(Node end) {
        List<BlockPos> list = new ArrayList<>();
        for (Node n = end; n != null; n = n.parent) list.add(n.pos);
        Collections.reverse(list);
        return list;
    }

    private static void neighbors(Level level, BlockPos n, List<Move> out) {
        for (Direction d : HORIZ) {
            BlockPos m0 = n.relative(d);
            if (standing(level, m0)) {
                out.add(new Move(m0, 1.0));
                continue;
            }
            // шаг вверх на 1 блок
            BlockPos up = m0.above();
            if (passable(level, n.above(2)) && standing(level, up)) {
                out.add(new Move(up, 2.2));
                continue;
            }
            // спрыгнуть вниз (до 3 блоков), иначе это обрыв и мы его обходим
            if (passable(level, m0) && passable(level, m0.above())) {
                for (int k = 1; k <= 3; k++) {
                    BlockPos c = m0.below(k);
                    if (!passable(level, c)) break;
                    if (standing(level, c)) {
                        out.add(new Move(c, 1.5 + k));
                        break;
                    }
                }
            }
        }
    }

    public static boolean standing(Level level, BlockPos feet) {
        if (feet.getY() <= level.getMinBuildHeight() + 1 || feet.getY() >= level.getMaxBuildHeight() - 2) return false;
        if (!level.hasChunkAt(feet)) return false;
        if (!passable(level, feet) || !passable(level, feet.above())) return false;
        if (!solidFloor(level, feet.below())) return false;
        return !lavaNear(level, feet) && !lavaNear(level, feet.above());
    }

    private static boolean passable(Level level, BlockPos pos) {
        if (!level.hasChunkAt(pos)) return false;
        BlockState s = level.getBlockState(pos);
        if (!s.getCollisionShape(level, pos).isEmpty()) return false;
        if (s.getFluidState().is(FluidTags.LAVA)) return false;
        return !(s.is(Blocks.FIRE) || s.is(Blocks.SOUL_FIRE) || s.is(Blocks.COBWEB)
                || s.is(Blocks.SWEET_BERRY_BUSH) || s.is(Blocks.POWDER_SNOW) || s.is(Blocks.WITHER_ROSE));
    }

    private static boolean solidFloor(Level level, BlockPos pos) {
        if (!level.hasChunkAt(pos)) return false;
        BlockState s = level.getBlockState(pos);
        if (s.getCollisionShape(level, pos).isEmpty()) return false;
        return !(s.is(Blocks.MAGMA_BLOCK) || s.is(Blocks.CACTUS) || s.is(Blocks.CAMPFIRE) || s.is(Blocks.SOUL_CAMPFIRE));
    }

    private static boolean lavaNear(Level level, BlockPos pos) {
        if (level.getFluidState(pos).is(FluidTags.LAVA)) return true;
        for (Direction d : Direction.values()) {
            if (level.getFluidState(pos.relative(d)).is(FluidTags.LAVA)) return true;
        }
        return false;
    }
}
