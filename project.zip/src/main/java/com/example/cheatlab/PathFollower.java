package com.example.cheatlab;

import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.core.BlockPos;
import net.minecraft.tags.FluidTags;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

import java.util.ArrayList;
import java.util.List;

/** Ведёт игрока к клетке по пути из Pathfinder (бег, прыжки, плавание). Прибытие проверяет вызывающий код. */
public final class PathFollower {
    private BlockPos goal;
    private List<BlockPos> path = new ArrayList<>();
    private int idx;
    private int sinceProgress;
    private int replans;
    private boolean failed;

    public boolean failed() { return failed; }

    public void reset() {
        goal = null;
        path = new ArrayList<>();
        idx = 0;
        sinceProgress = 0;
        replans = 0;
        failed = false;
    }

    /** Новая цель. Небольшие смещения цели (до 2 блоков) путь не сбрасывают. */
    public void setGoal(BlockPos g) {
        if (goal != null && goal.distSqr(g) <= 4) return;
        goal = g;
        path = new ArrayList<>();
        idx = 0;
        sinceProgress = 0;
        replans = 0;
        failed = false;
    }

    public static void releaseKeys(Minecraft mc) {
        if (mc.options == null) return;
        mc.options.keyUp.setDown(false);
        mc.options.keyJump.setDown(false);
        mc.options.keySprint.setDown(false);
    }

    private void fail(Minecraft mc) {
        failed = true;
        releaseKeys(mc);
    }

    private static BlockPos last(Pathfinder.Result r) {
        return r.nodes().get(r.nodes().size() - 1);
    }

    private void plan(Level level, BlockPos start) {
        Pathfinder.Result r = Pathfinder.find(level, start, goal, false);
        if (!r.complete()) {
            Pathfinder.Result r2 = Pathfinder.find(level, start, goal, true);
            if (r2.complete() || Pathfinder.h(last(r2), goal) < Pathfinder.h(last(r), goal) - 0.5) r = r2;
        }
        path = new ArrayList<>(r.nodes());
        idx = 1;
        sinceProgress = 0;
    }

    private static boolean nodeReached(Level level, BlockPos feet, BlockPos node, boolean swimming) {
        if (feet.equals(node)) return true;
        boolean nodeWater = level.getFluidState(node).is(FluidTags.WATER);
        if (swimming || nodeWater) {
            return feet.getX() == node.getX() && feet.getZ() == node.getZ() && Math.abs(feet.getY() - node.getY()) <= 1;
        }
        return false;
    }

    public void tick(Minecraft mc, LocalPlayer p) {
        Level level = mc.level;
        if (goal == null || failed || level == null) {
            releaseKeys(mc);
            return;
        }
        BlockPos feet = p.blockPosition();
        if (idx >= path.size()) {
            if (++replans > 20) {
                fail(mc);
                return;
            }
            plan(level, feet);
            if (path.size() <= 1) fail(mc);
            return;
        }
        boolean swimming = p.isInWater();
        BlockPos next = path.get(idx);
        if (nodeReached(level, feet, next, swimming)) {
            idx++;
            sinceProgress = 0;
            return;
        }
        for (int j = idx + 1; j < Math.min(path.size(), idx + 4); j++) {
            if (nodeReached(level, feet, path.get(j), swimming)) {
                idx = j + 1;
                sinceProgress = 0;
                return;
            }
        }
        if (feet.distSqr(next) > 25 || ++sinceProgress > 100) {
            if (++replans > 20) {
                fail(mc);
                return;
            }
            plan(level, feet);
            if (path.size() <= 1) fail(mc);
            return;
        }

        Vec3 want = Vec3.atBottomCenterOf(next);
        double dx = want.x - p.getX();
        double dz = want.z - p.getZ();
        double hd = Math.sqrt(dx * dx + dz * dz);
        if (hd > 0.08) p.setYRot((float) Math.toDegrees(Math.atan2(-dx, dz)));
        mc.options.keyUp.setDown(hd > 0.2);
        mc.options.keySprint.setDown(!swimming && hd > 0.6 && p.getFoodData().getFoodLevel() > 6);
        boolean jump = swimming
                || (p.onGround() && (next.getY() > feet.getY() || (p.horizontalCollision && hd > 0.3)));
        mc.options.keyJump.setDown(jump);
    }
}
