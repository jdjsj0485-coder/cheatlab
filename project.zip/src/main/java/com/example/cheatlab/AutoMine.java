package com.example.cheatlab;

import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.tags.FluidTags;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.item.PickaxeItem;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * Авто-добыча: с киркой в руке идёт к ближайшей выбранной руде, прокладывая туннель 1x2,
 * добывает её и берёт следующую. Останавливается у лавы, при низком здоровье и без кирки.
 */
public final class AutoMine {
    public static boolean enabled;

    private static BlockPos target;
    private static BlockPos stepTarget;
    private static final List<BlockPos> toClear = new ArrayList<>();
    private static final Set<BlockPos> skipped = new HashSet<>();
    private static int stuck;
    private static BlockPos lastFeet;

    private AutoMine() {}

    public static void toggle() {
        Minecraft mc = Minecraft.getInstance();
        LocalPlayer p = mc.player;
        if (p == null) return;
        if (enabled) {
            stop("[CheatLab] Auto-mine: OFF");
            return;
        }
        if (!(p.getMainHandItem().getItem() instanceof PickaxeItem)) {
            Modules.say("[CheatLab] Hold a pickaxe in your main hand first.");
            return;
        }
        if (Modules.fly) {
            Modules.say("[CheatLab] Turn Fly off first (Auto-mine walks and digs by itself).");
            return;
        }
        boolean any = false;
        for (Xray.Ore o : Xray.ORES) any |= o.enabled;
        if (!any) {
            Modules.say("[CheatLab] Select ores first (menu: Ores to find).");
            return;
        }
        GoTo.stop(null);
        enabled = true;
        skipped.clear();
        dropTarget();
        Xray.markDirty();
        Modules.say("[CheatLab] Auto-mine: ON. Press the key again to stop.");
    }

    public static void stop(String message) {
        enabled = false;
        dropTarget();
        releaseKeys(Minecraft.getInstance());
        if (message != null) Modules.say(message);
    }

    private static void dropTarget() {
        target = null;
        stepTarget = null;
        toClear.clear();
        stuck = 0;
        lastFeet = null;
    }

    private static void releaseKeys(Minecraft mc) {
        if (mc.options == null) return;
        mc.options.keyUp.setDown(false);
        mc.options.keyJump.setDown(false);
    }

    public static void tick(Minecraft mc, LocalPlayer p) {
        if (!enabled) return;
        if (mc.level == null || mc.gameMode == null) return;
        if (mc.screen != null) {
            releaseKeys(mc);
            return;
        }
        if (Modules.fly || p.isPassenger()) {
            stop("[CheatLab] Auto-mine stopped (Fly or vehicle).");
            return;
        }
        if (!(p.getMainHandItem().getItem() instanceof PickaxeItem)) {
            stop("[CheatLab] Auto-mine stopped: no pickaxe in hand.");
            return;
        }
        if (p.getHealth() < 6.0f) {
            stop("[CheatLab] Auto-mine stopped: low health.");
            return;
        }

        Level level = mc.level;
        BlockPos feet = p.blockPosition();

        // выбрать цель
        if (target == null) {
            target = pickTarget(level, p);
            if (target == null) {
                stop("[CheatLab] Auto-mine finished: no selected ores nearby.");
                return;
            }
            stepTarget = null;
            toClear.clear();
            stuck = 0;
        }

        // дошли до цели (или добыли руду над головой)
        if (feet.equals(target) || (feet.above().equals(target) && level.getBlockState(target).isAir())) {
            dropTarget();
            releaseKeys(mc);
            return;
        }

        // застряли
        if (lastFeet == null || !lastFeet.equals(feet)) {
            lastFeet = feet;
            stuck = 0;
        }
        if (++stuck > 600) {
            skipped.add(target);
            dropTarget();
            releaseKeys(mc);
            Modules.say("[CheatLab] Could not reach an ore, skipping it.");
            return;
        }

        // упали или сдвинулись далеко от плана
        if (stepTarget != null && feet.distSqr(stepTarget) > 9) {
            stepTarget = null;
            toClear.clear();
        }

        if (stepTarget == null) {
            plan(level, feet, target);
            if (stepTarget == null) return; // цель пропущена
        }

        // 1) расчистить путь
        for (BlockPos pos : toClear) {
            BlockState st = level.getBlockState(pos);
            if (needsMining(level, pos, st)) {
                if (st.getDestroySpeed(level, pos) < 0) {
                    skipTarget("[CheatLab] Unbreakable block in the way, skipping ore.");
                    releaseKeys(mc);
                    return;
                }
                releaseKeys(mc);
                mine(mc, p, pos);
                return;
            }
        }

        // 2) идти в клетку
        if (feet.equals(stepTarget)) {
            stepTarget = null;
            toClear.clear();
            releaseKeys(mc);
            return;
        }
        Vec3 want = Vec3.atBottomCenterOf(stepTarget);
        double dx = want.x - p.getX();
        double dz = want.z - p.getZ();
        double hd = Math.sqrt(dx * dx + dz * dz);
        if (hd > 0.1) {
            p.setYRot((float) Math.toDegrees(Math.atan2(-dx, dz)));
        }
        mc.options.keyUp.setDown(hd > 0.2);
        boolean needJump = p.onGround() && (stepTarget.getY() > feet.getY() || p.horizontalCollision);
        mc.options.keyJump.setDown(needJump);
    }

    private static BlockPos pickTarget(Level level, LocalPlayer p) {
        BlockPos best = null;
        double bestD = Double.MAX_VALUE;
        BlockPos me = p.blockPosition();
        for (Xray.Hit h : Xray.hits()) {
            BlockPos pos = h.pos();
            if (skipped.contains(pos)) continue;
            if (!Xray.isSelectedOre(level.getBlockState(pos))) continue;
            double d = me.distSqr(pos);
            if (d < bestD) {
                bestD = d;
                best = pos;
            }
        }
        return best;
    }

    private static void skipTarget(String why) {
        if (target != null) skipped.add(target);
        dropTarget();
        Modules.say(why);
    }

    /** Составляет следующий шаг: какие клетки расчистить и куда встать. */
    private static void plan(Level level, BlockPos f, BlockPos t) {
        toClear.clear();
        stepTarget = null;
        int dx = t.getX() - f.getX();
        int dy = t.getY() - f.getY();
        int dz = t.getZ() - f.getZ();

        if (dx == 0 && dz == 0) {
            if (dy == 1) {            // руда прямо над головой
                toClear.add(t);
                stepTarget = f;
            } else if (dy < 0) {      // копаем вниз
                BlockPos nf = f.below();
                toClear.add(nf);
                stepTarget = nf;
            } else if (dy >= 2) {     // лезем вверх ступенями
                ascend(f, Direction.EAST);
            } else {
                stepTarget = f;
            }
        } else {
            Direction d = Math.abs(dx) >= Math.abs(dz)
                    ? (dx > 0 ? Direction.EAST : Direction.WEST)
                    : (dz > 0 ? Direction.SOUTH : Direction.NORTH);
            if (dy > 0) ascend(f, d);
            else if (dy < 0) descend(f, d);
            else flat(f, d);
        }

        if (stepTarget == null) return;

        // безопасность: лава рядом или слишком глубокий обрыв
        List<BlockPos> check = new ArrayList<>(toClear);
        check.add(stepTarget);
        check.add(stepTarget.below());
        for (BlockPos pos : check) {
            if (lavaNear(level, pos)) {
                skipTarget("[CheatLab] Lava nearby, skipping this ore.");
                stepTarget = null;
                return;
            }
        }
        if (dropTooBig(level, stepTarget)) {
            skipTarget("[CheatLab] Big drop ahead, skipping this ore.");
            stepTarget = null;
        }
    }

    private static void flat(BlockPos f, Direction d) {
        BlockPos n = f.relative(d);
        toClear.add(n);
        toClear.add(n.above());
        stepTarget = n;
    }

    private static void descend(BlockPos f, Direction d) {
        BlockPos n = f.relative(d);
        toClear.add(n);
        toClear.add(n.above());
        toClear.add(n.below());
        stepTarget = n.below();
    }

    private static void ascend(BlockPos f, Direction d) {
        BlockPos n = f.relative(d);
        toClear.add(f.above(2));
        toClear.add(n.above());
        toClear.add(n.above(2));
        stepTarget = n.above();
    }

    private static boolean needsMining(Level level, BlockPos pos, BlockState st) {
        if (st.isAir()) return false;
        return !st.getCollisionShape(level, pos).isEmpty();
    }

    private static boolean lavaNear(Level level, BlockPos pos) {
        if (level.getFluidState(pos).is(FluidTags.LAVA)) return true;
        for (Direction d : Direction.values()) {
            if (level.getFluidState(pos.relative(d)).is(FluidTags.LAVA)) return true;
        }
        return false;
    }

    private static boolean dropTooBig(Level level, BlockPos stand) {
        int air = 0;
        BlockPos q = stand.below();
        for (int i = 0; i < 3; i++) {
            BlockState s = level.getBlockState(q);
            if (s.getCollisionShape(level, q).isEmpty() && s.getFluidState().isEmpty()) air++;
            else break;
            q = q.below();
        }
        return air >= 3;
    }

    private static void mine(Minecraft mc, LocalPlayer p, BlockPos pos) {
        Vec3 eye = p.getEyePosition();
        Vec3 c = Vec3.atCenterOf(pos);
        double dx = c.x - eye.x, dy = c.y - eye.y, dz = c.z - eye.z;
        double h = Math.sqrt(dx * dx + dz * dz);
        p.setYRot((float) Math.toDegrees(Math.atan2(-dx, dz)));
        p.setXRot((float) -Math.toDegrees(Math.atan2(dy, h)));
        Direction face = Direction.getNearest(-dx, -dy, -dz);
        mc.gameMode.continueDestroyBlock(pos, face);
        p.swing(InteractionHand.MAIN_HAND);
    }
}
