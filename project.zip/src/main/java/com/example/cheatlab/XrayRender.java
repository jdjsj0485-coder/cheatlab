package com.example.cheatlab;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.LevelRenderer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.core.BlockPos;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RenderLevelStageEvent;
import net.minecraftforge.eventbus.api.EventPriority;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.List;

@Mod.EventBusSubscriber(modid = CheatLab.MODID, bus = Mod.EventBusSubscriber.Bus.FORGE, value = Dist.CLIENT)
public class XrayRender {
    @SubscribeEvent(priority = EventPriority.LOWEST)
    public static void onRender(RenderLevelStageEvent e) {
        if (e.getStage() != RenderLevelStageEvent.Stage.AFTER_TRANSLUCENT_BLOCKS) return;
        List<Xray.Hit> list = Xray.enabled ? Xray.hits() : List.of();
        List<BlockPos> route = GoTo.renderPath();
        if (list.isEmpty() && route.isEmpty()) return;
        try {
            Minecraft mc = Minecraft.getInstance();
            PoseStack ps = e.getPoseStack();
            Vec3 cam = e.getCamera().getPosition();
            MultiBufferSource.BufferSource buf = mc.renderBuffers().bufferSource();
            VertexConsumer vc = buf.getBuffer(XrayRenderType.LINES);
            ps.pushPose();
            ps.translate(-cam.x, -cam.y, -cam.z);

            // руды сквозь стены
            for (Xray.Hit h : list) {
                float r = ((h.color() >> 16) & 255) / 255f;
                float g = ((h.color() >> 8) & 255) / 255f;
                float b = (h.color() & 255) / 255f;
                LevelRenderer.renderLineBox(ps, vc, new AABB(h.pos()).inflate(0.002), r, g, b, 1f);
            }

            // маршрут бота: красная линия
            int limit = Math.min(route.size(), 400);
            for (int i = 0; i + 1 < limit; i++) {
                BlockPos a = route.get(i);
                BlockPos c = route.get(i + 1);
                line(ps, vc,
                        new Vec3(a.getX() + 0.5, a.getY() + 0.15, a.getZ() + 0.5),
                        new Vec3(c.getX() + 0.5, c.getY() + 0.15, c.getZ() + 0.5),
                        1f, 0.1f, 0.1f);
            }
            BlockPos goal = GoTo.goal();
            if (goal != null) {
                LevelRenderer.renderLineBox(ps, vc, new AABB(goal).inflate(0.05), 1f, 0.1f, 0.1f, 1f);
            }

            ps.popPose();
            buf.endBatch(XrayRenderType.LINES);
        } catch (Throwable t) {
            Modules.error("xray-render", t);
        }
    }

    private static void line(PoseStack ps, VertexConsumer vc, Vec3 a, Vec3 b, float r, float g, float bl) {
        PoseStack.Pose pose = ps.last();
        float dx = (float) (b.x - a.x);
        float dy = (float) (b.y - a.y);
        float dz = (float) (b.z - a.z);
        float len = (float) Math.sqrt(dx * dx + dy * dy + dz * dz);
        if (len < 1.0e-4f) return;
        dx /= len;
        dy /= len;
        dz /= len;
        vc.vertex(pose.pose(), (float) a.x, (float) a.y, (float) a.z).color(r, g, bl, 1f).normal(pose.normal(), dx, dy, dz).endVertex();
        vc.vertex(pose.pose(), (float) b.x, (float) b.y, (float) b.z).color(r, g, bl, 1f).normal(pose.normal(), dx, dy, dz).endVertex();
    }
}
