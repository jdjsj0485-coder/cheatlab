package com.example.cheatlab;

import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.tags.BlockTags;
import net.minecraft.tags.FluidTags;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.animal.Animal;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.item.AxeItem;
import net.minecraft.world.item.SwordItem;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.CropBlock;
import net.minecraft.world.level.block.SweetBerryBushBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.Vec3;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

/**
 * Сбор ресурсов: еда (охота на коров, свиней, овец, кроликов + спелые морковь, картофель, свёкла, арбузы, ягоды),
 * дерево, камень, песок, гравий, земля. Сам идёт к цели, добывает и подбирает дроп.
 */
public final class Gatherer {
    public enum Kind {
        FOOD("food"), WOOD("wood"), STONE("stone"), SAND("sand"), GRAVEL("gravel"), DIRT("dirt");

        public final String label;

        Kind(String label) { this.label = label; }

        public static Kind byName(String s) {
            for (Kind k : values()) if (k.label.equalsIgnoreCase(s)) return k;
            return null;
        }
    }

    private static final class Target {
        static final int BLOCK = 0, ENTITY = 1, ITEM = 2;
        final int type;
        final BlockPos pos;
        final Entity entity;
        BlockPos stand;
        int ticks;

        Target(int type, BlockPos pos, Entity entity) {
            this.type = type;
            this.pos = pos;
            this.entity = entity;
        }
    }

    public static boolean active;

    private static Kind kind = Kind.FOOD;
    private static int want, got, radius, totalTicks;
    private static boolean resumeWalk;
    private static boolean dropPhase;
    private static BlockPos lastTarget;
    private static Target cur;
    private static long nextForage;
    private static final PathFollower follower = new PathFollower();
    private static final Set<BlockPos> skippedBlocks = new HashSet<>();
    private static final Set<Integer> skippedEntities = new HashSet<>();

    private Gatherer() {}

    public static List<String> kindNames() {
        List<String> l = new ArrayList<>();
        for (Kind k : Kind.values()) l.add(k.label);
        return l;
    }

    public static boolean canForage(long now) { return now >= nextForage; }

    public static String statusLine() {
        if (!active) return null;
        int have = kind == Kind.FOOD ? currentFood() : got;
        return "Gather " + kind.label + ": " + have + "/" + want;
    }

    private static int currentFood() {
        Minecraft mc = Minecraft.getInstance();
        return mc.player == null ? 0 : AutoEat.foodCount(mc.player);
    }

    /** Вызывается ходьбой: голоден, еды нет, нужно найти еду и вернуться к маршруту. */
    public static void startForage() {
        start(Kind.FOOD, 3, 40, true);
    }

    public static void start(Kind k, int amount, int rad, boolean resume) {
        Minecraft mc = Minecraft.getInstance();
        LocalPlayer p = mc.player;
        if (p == null || mc.level == null) return;
        if (Modules.fly) {
            Modules.say("[CheatLab] Turn Fly off first.");
            return;
        }
        if (AutoMine.enabled) AutoMine.stop("[CheatLab] Auto-mine stopped.");
        if (!resume) GoTo.stop(null);
        kind = k;
        want = amount;
        radius = Math.max(8, Math.min(64, rad));
        got = 0;
        totalTicks = 0;
        dropPhase = false;
        lastTarget = null;
        cur = null;
        resumeWalk = resume;
        skippedBlocks.clear();
        skippedEntities.clear();
        follower.reset();
        active = true;
        if (resume) {
            Modules.say("[CheatLab] Hungry and no food: pausing the route to find food (radius " + radius + ").");
        } else {
            Modules.say("[CheatLab] Gathering " + k.label + " x" + amount + " within " + radius + " blocks. Stop: /cheatlab stop");
        }
    }

    public static void stop(String message) {
        boolean was = active;
        active = false;
        resumeWalk = false;
        cur = null;
        follower.reset();
        PathFollower.releaseKeys(Minecraft.getInstance());
        AutoEat.abort();
        if (was && message != null) Modules.say(message);
    }

    private static void finish(String message, boolean success) {
        boolean resume = resumeWalk;
        Minecraft mc = Minecraft.getInstance();
        active = false;
        resumeWalk = false;
        cur = null;
        follower.reset();
        PathFollower.releaseKeys(mc);
        if (resume && !success && mc.level != null) nextForage = mc.level.getGameTime() + 1200;
        Modules.say(message);
        if (resume) GoTo.requestReplan();
    }

    public static void tick(Minecraft mc, LocalPlayer p) {
        if (!active) return;
        Level level = mc.level;
        if (level == null || mc.gameMode == null) return;
        if (mc.screen != null) {
            PathFollower.releaseKeys(mc);
            return;
        }
        if (Modules.fly || p.isPassenger()) {
            stop("[CheatLab] Gathering stopped (Fly or vehicle).");
            return;
        }
        if (p.getHealth() < 8.0f) {
            stop("[CheatLab] Gathering stopped: low health.");
            return;
        }
        if (++totalTicks > 6000) {
            finish("[CheatLab] Gathering time limit reached.", false);
            return;
        }
        if (AutoEat.tick(mc, p)) {
            PathFollower.releaseKeys(mc);
            return;
        }

        if (kind == Kind.FOOD) {
            int have = AutoEat.foodCount(p);
            if (have >= want || (resumeWalk && p.getFoodData().getFoodLevel() >= 18)) {
                finish("[CheatLab] Got food (" + have + " items).", true);
                return;
            }
        } else if (got >= want) {
            finish("[CheatLab] Gathered " + got + " " + kind.label + ".", true);
            return;
        }

        if (cur == null) {
            follower.reset();
            cur = chooseTarget(mc, p, level);
            if (cur == null) {
                finish("[CheatLab] Nothing to gather nearby (" + kind.label + ", radius " + radius + ").", false);
                return;
            }
        }
        runTarget(mc, p, level);
    }

    // ---------------- выбор цели ----------------

    private static Target chooseTarget(Minecraft mc, LocalPlayer p, Level level) {
        if (dropPhase && lastTarget != null) {
            Target d = chooseDrop(mc, p);
            if (d != null) return d;
            dropPhase = false;
        }
        if (kind == Kind.FOOD) {
            Target a = nearestAnimal(mc, p);
            Target b = nearestBlock(level, p);
            if (a == null) return b;
            if (b == null) return a;
            return p.distanceToSqr(a.entity) <= p.distanceToSqr(Vec3.atCenterOf(b.pos)) ? a : b;
        }
        return nearestBlock(level, p);
    }

    private static Target chooseDrop(Minecraft mc, LocalPlayer p) {
        Entity best = null;
        double bd = Double.MAX_VALUE;
        Vec3 center = Vec3.atCenterOf(lastTarget);
        for (Entity e : mc.level.entitiesForRendering()) {
            if (!(e instanceof ItemEntity ie) || !ie.isAlive()) continue;
            if (skippedEntities.contains(ie.getId())) continue;
            if (ie.distanceToSqr(center) > 64.0) continue;
            if (kind == Kind.FOOD && !AutoEat.safeFood(ie.getItem())) continue;
            double d = ie.distanceToSqr(p);
            if (d < bd) {
                bd = d;
                best = ie;
            }
        }
        if (best == null) return null;
        return new Target(Target.ITEM, best.blockPosition(), best);
    }

    private static Target nearestAnimal(Minecraft mc, LocalPlayer p) {
        Entity best = null;
        double bd = Double.MAX_VALUE;
        double max = (double) radius * radius;
        for (Entity e : mc.level.entitiesForRendering()) {
            if (!(e instanceof Animal a) || !a.isAlive() || a.isBaby()) continue;
            EntityType<?> t = e.getType();
            if (t != EntityType.COW && t != EntityType.PIG && t != EntityType.SHEEP && t != EntityType.RABBIT) continue;
            if (skippedEntities.contains(e.getId())) continue;
            double d = e.distanceToSqr(p);
            if (d > max) continue;
            if (d < bd) {
                bd = d;
                best = e;
            }
        }
        if (best == null) return null;
        return new Target(Target.ENTITY, best.blockPosition(), best);
    }

    private static boolean matches(BlockState s) {
        switch (kind) {
            case WOOD: return s.is(BlockTags.LOGS);
            case STONE: return s.is(BlockTags.BASE_STONE_OVERWORLD);
            case SAND: return s.is(BlockTags.SAND);
            case GRAVEL: return s.is(Blocks.GRAVEL);
            case DIRT: return s.is(BlockTags.DIRT);
            default: return isFoodBlock(s);
        }
    }

    private static boolean isFoodBlock(BlockState s) {
        Block b = s.getBlock();
        if (b == Blocks.CARROTS || b == Blocks.POTATOES || b == Blocks.BEETROOTS) {
            return b instanceof CropBlock cb && cb.isMaxAge(s);
        }
        if (b == Blocks.MELON) return true;
        if (b == Blocks.SWEET_BERRY_BUSH) return s.getValue(SweetBerryBushBlock.AGE) >= 2;
        return false;
    }

    private static boolean lavaNear(Level level, BlockPos pos) {
        if (level.getFluidState(pos).is(FluidTags.LAVA)) return true;
        for (Direction d : Direction.values()) {
            if (level.getFluidState(pos.relative(d)).is(FluidTags.LAVA)) return true;
        }
        return false;
    }

    private static Target nearestBlock(Level level, LocalPlayer p) {
        BlockPos c = p.blockPosition();
        int r = radius;
        int ry = Math.min(r, 20);
        int minY = Math.max(level.getMinBuildHeight(), c.getY() - ry);
        int maxY = Math.min(level.getMaxBuildHeight() - 1, c.getY() + ry);
        boolean ground = kind == Kind.STONE || kind == Kind.SAND || kind == Kind.GRAVEL || kind == Kind.DIRT;
        List<BlockPos> list = new ArrayList<>();
        BlockPos.MutableBlockPos m = new BlockPos.MutableBlockPos();
        for (int x = c.getX() - r; x <= c.getX() + r; x++) {
            for (int z = c.getZ() - r; z <= c.getZ() + r; z++) {
                m.set(x, c.getY(), z);
                if (!level.hasChunkAt(m)) continue;
                for (int y = minY; y <= maxY; y++) {
                    if (ground && y < c.getY()) continue; // не копаем яму под собой
                    m.set(x, y, z);
                    if (!matches(level.getBlockState(m))) continue;
                    BlockPos imm = m.immutable();
                    if (skippedBlocks.contains(imm)) continue;
                    list.add(imm);
                    if (list.size() > 5000) break;
                }
            }
        }
        list.sort(Comparator.comparingDouble((BlockPos pos) -> pos.distSqr(c)));
        int tried = 0;
        for (BlockPos pos : list) {
            if (tried++ > 15) break;
            if (lavaNear(level, pos)) {
                skippedBlocks.add(pos);
                continue;
            }
            BlockPos stand = findStand(level, pos, c);
            if (stand != null) {
                Target t = new Target(Target.BLOCK, pos, null);
                t.stand = stand;
                return t;
            }
            skippedBlocks.add(pos);
        }
        return null;
    }

    /** Клетка, где можно стоять и дотянуться до блока (до 4.2 блоков от глаз). */
    private static BlockPos findStand(Level level, BlockPos target, BlockPos from) {
        BlockPos best = null;
        double bestD = Double.MAX_VALUE;
        Vec3 tc = Vec3.atCenterOf(target);
        for (int dx = -3; dx <= 3; dx++) {
            for (int dz = -3; dz <= 3; dz++) {
                for (int dy = -5; dy <= 1; dy++) {
                    BlockPos c = target.offset(dx, dy, dz);
                    if (c.equals(target) || c.above().equals(target)) continue;
                    if (!Pathfinder.standing(level, c, false)) continue;
                    Vec3 eye = Vec3.atBottomCenterOf(c).add(0.0, 1.62, 0.0);
                    if (eye.distanceToSqr(tc) > 4.2 * 4.2) continue;
                    double d = c.distSqr(from);
                    if (d < bestD) {
                        bestD = d;
                        best = c;
                    }
                }
            }
        }
        return best;
    }

    // ---------------- действия ----------------

    private static void skip(Target t) {
        if (t.type == Target.BLOCK) skippedBlocks.add(t.pos);
        else if (t.entity != null) skippedEntities.add(t.entity.getId());
        cur = null;
        follower.reset();
        PathFollower.releaseKeys(Minecraft.getInstance());
    }

    private static void runTarget(Minecraft mc, LocalPlayer p, Level level) {
        Target t = cur;
        if (++t.ticks > 1200) {
            skip(t);
            return;
        }
        if (t.type == Target.BLOCK) block(mc, p, level, t);
        else if (t.type == Target.ENTITY) entity(mc, p, t);
        else item(mc, p, t);
    }

    private static void block(Minecraft mc, LocalPlayer p, Level level, Target t) {
        BlockState st = level.getBlockState(t.pos);
        if (!matches(st)) {
            if (kind != Kind.FOOD) got++;
            lastTarget = t.pos;
            dropPhase = true;
            cur = null;
            PathFollower.releaseKeys(mc);
            return;
        }
        if (p.getEyePosition().distanceToSqr(Vec3.atCenterOf(t.pos)) <= 4.3 * 4.3) {
            PathFollower.releaseKeys(mc);
            harvest(mc, p, t.pos, st);
            return;
        }
        follower.setGoal(t.stand);
        follower.tick(mc, p);
        if (follower.failed()) skip(t);
    }

    private static void entity(Minecraft mc, LocalPlayer p, Target t) {
        Entity e = t.entity;
        if (e == null || !e.isAlive() || e.isRemoved()) {
            lastTarget = e != null ? e.blockPosition() : p.blockPosition();
            dropPhase = true;
            cur = null;
            PathFollower.releaseKeys(mc);
            return;
        }
        if (p.distanceTo(e) > 2.8f) {
            follower.setGoal(e.blockPosition());
            follower.tick(mc, p);
            if (follower.failed()) skip(t);
            return;
        }
        PathFollower.releaseKeys(mc);
        lookAt(p, e.getEyePosition());
        if (p.getAttackStrengthScale(0.5f) >= 1.0f) {
            selectWeapon(p);
            mc.gameMode.attack(p, e);
            p.swing(InteractionHand.MAIN_HAND);
        }
    }

    private static void item(Minecraft mc, LocalPlayer p, Target t) {
        Entity e = t.entity;
        if (e == null || !e.isAlive() || e.isRemoved()) {
            cur = null;
            PathFollower.releaseKeys(mc);
            return;
        }
        if (p.distanceToSqr(e) < 1.0) {
            PathFollower.releaseKeys(mc); // подбор происходит сам
            return;
        }
        follower.setGoal(e.blockPosition());
        follower.tick(mc, p);
        if (follower.failed()) skip(t);
    }

    private static void harvest(Minecraft mc, LocalPlayer p, BlockPos pos, BlockState st) {
        lookAt(p, Vec3.atCenterOf(pos));
        if (st.is(Blocks.SWEET_BERRY_BUSH)) {
            if (p.tickCount % 10 == 0) {
                BlockHitResult hit = new BlockHitResult(Vec3.atCenterOf(pos), Direction.UP, pos, false);
                mc.gameMode.useItemOn(p, InteractionHand.MAIN_HAND, hit);
                p.swing(InteractionHand.MAIN_HAND);
            }
            return;
        }
        selectBestTool(p, st);
        Vec3 eye = p.getEyePosition();
        Vec3 c = Vec3.atCenterOf(pos);
        Direction face = Direction.getNearest(eye.x - c.x, eye.y - c.y, eye.z - c.z);
        mc.gameMode.continueDestroyBlock(pos, face);
        p.swing(InteractionHand.MAIN_HAND);
    }

    private static void selectBestTool(LocalPlayer p, BlockState st) {
        int best = p.getInventory().selected;
        float bs = p.getInventory().getItem(best).getDestroySpeed(st);
        for (int i = 0; i < 9; i++) {
            float s = p.getInventory().getItem(i).getDestroySpeed(st);
            if (s > bs) {
                bs = s;
                best = i;
            }
        }
        p.getInventory().selected = best;
    }

    private static void selectWeapon(LocalPlayer p) {
        int best = -1;
        for (int i = 0; i < 9; i++) {
            var item = p.getInventory().getItem(i).getItem();
            if (item instanceof SwordItem) {
                best = i;
                break;
            }
            if (best < 0 && item instanceof AxeItem) best = i;
        }
        if (best >= 0) p.getInventory().selected = best;
    }

    private static void lookAt(LocalPlayer p, Vec3 target) {
        Vec3 eye = p.getEyePosition();
        double dx = target.x - eye.x, dy = target.y - eye.y, dz = target.z - eye.z;
        double h = Math.sqrt(dx * dx + dz * dz);
        p.setYRot((float) Math.toDegrees(Math.atan2(-dx, dz)));
        p.setXRot((float) -Math.toDegrees(Math.atan2(dy, h)));
    }

    public static String describe() {
        return kind.label.toUpperCase(Locale.ROOT);
    }
}
