package com.example.cheatlab;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RenderGuiOverlayEvent;
import net.minecraftforge.client.gui.overlay.VanillaGuiOverlay;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.ArrayList;
import java.util.List;

/** Маленький список включённых функций и статус бота в углу экрана. */
@Mod.EventBusSubscriber(modid = CheatLab.MODID, bus = Mod.EventBusSubscriber.Bus.FORGE, value = Dist.CLIENT)
public class Hud {
    @SubscribeEvent
    public static void onOverlay(RenderGuiOverlayEvent.Post e) {
        if (e.getOverlay() != VanillaGuiOverlay.HOTBAR.type()) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.options.hideGui) return;
        try {
            List<String> lines = new ArrayList<>();
            if (Modules.fly) lines.add("Fly");
            if (Modules.esp) lines.add("Player ESP");
            if (Modules.boatFly) lines.add("Boat Fly");
            if (Xray.enabled) lines.add("X-Ray");
            if (Modules.night) lines.add("Night vision");
            if (AutoMine.enabled) lines.add("Auto-mine");
            String walk = GoTo.statusLine(mc.player);
            if (walk != null) lines.add(walk);
            String gather = Gatherer.statusLine();
            if (gather != null) lines.add(gather);
            if (lines.isEmpty()) return;

            GuiGraphics g = e.getGuiGraphics();
            int y = 4;
            g.drawString(mc.font, "CheatLab", 4, y, 0x55AAFF, true);
            y += 10;
            for (String s : lines) {
                g.drawString(mc.font, s, 4, y, 0x55FF55, true);
                y += 10;
            }
        } catch (Throwable t) {
            Modules.error("hud", t);
        }
    }
}
