package com.example.cheatlab;

import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.ChatFormatting;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.AbstractWidget;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.network.chat.Component;
import net.minecraft.util.Mth;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class CheatMenuScreen extends Screen {
    private static final int W = 190, H = 316;
    private static final int ALL = -1;
    private static final int P_HACKS = 0, P_BOT = 1, P_FIND = 2, P_KEYS = 3;

    // список структур (вкладка Find)
    private static final int ROWS = 8, ROWH = 12, LIST_X = 6, LIST_Y = 68, LIST_W = 160;
    // результаты поиска
    private static final int RES_Y = 204, RES_ROWS = 6, RES_H = 11;

    private static int px = -1, py = -1; // позиция окна запоминается
    private static int lastPage = P_HACKS;
    private static String sX = "", sY = "", sZ = "", sAmount = "16", sGRadius = "32", sFindRadius = "1000", sSearch = "";
    private static int gatherIdx = 0;
    private static String selectedStructure = null;
    private static int listScroll = 0;

    private static final String[] KEY_LABELS = {
            "Open menu", "Fly", "Player ESP", "Boat Fly", "X-Ray", "Auto-mine", "Night vision", "Boat faster", "Boat slower"
    };

    private record Entry(AbstractWidget w, int dx, int dy, int page) {}

    private final List<Entry> entries = new ArrayList<>();
    private boolean dragging;
    private int dragDX, dragDY;
    private KeyMapping listening;
    private int page = lastPage;

    private List<String> allStructures = new ArrayList<>();
    private List<String> filtered = new ArrayList<>();

    private final Button[] tabs = new Button[4];
    private Button flyBtn, espBtn, boatBtn, xrayBtn, autoBtn, nightBtn;
    private Button flyKey, espKey, boatKey, xrayKey, autoKey, nightKey;
    private final Button[] oreBtns = new Button[Xray.ORES.length];
    private final Button[] keyBtns = new Button[KEY_LABELS.length];
    private EditBox xBox, yBox, zBox, amountBox, gRadiusBox, searchBox, findRadiusBox;
    private Button gatherKindBtn, eatBtn, forageBtn, findBtn;

    public CheatMenuScreen() {
        super(Component.literal("CheatLab"));
    }

    private static KeyMapping[] keyMaps() {
        return new KeyMapping[]{
                ModEvents.MENU, ModEvents.FLY, ModEvents.ESP, ModEvents.BOAT,
                ModEvents.XRAY, ModEvents.AUTOMINE, ModEvents.NIGHT, ModEvents.BOAT_FASTER, ModEvents.BOAT_SLOWER
        };
    }

    private Button btn(int w, int h, String text, Button.OnPress press) {
        return Button.builder(Component.literal(text), press).bounds(0, 0, w, h).build();
    }

    private EditBox box(int w, String init, int maxLen, boolean numeric) {
        EditBox b = new EditBox(font, 0, 0, w, 16, Component.empty());
        b.setMaxLength(maxLen);
        if (numeric) b.setFilter(s -> s.matches("-?\\d*"));
        b.setValue(init);
        return b;
    }

    private <T extends AbstractWidget> T put(T w, int dx, int dy, int pg) {
        entries.add(new Entry(w, dx, dy, pg));
        w.setX(px + dx);
        w.setY(py + dy);
        return addRenderableWidget(w);
    }

    private static Integer parseInt(EditBox b) {
        try {
            return Integer.parseInt(b.getValue().trim());
        } catch (NumberFormatException e) {
            return null;
        }
    }

    private void saveTexts() {
        if (xBox == null) return;
        sX = xBox.getValue();
        sY = yBox.getValue();
        sZ = zBox.getValue();
        sAmount = amountBox.getValue();
        sGRadius = gRadiusBox.getValue();
        sFindRadius = findRadiusBox.getValue();
        sSearch = searchBox.getValue();
    }

    private void setPage(int pg) {
        page = pg;
        lastPage = pg;
        listening = null;
        applyPage();
        refresh();
    }

    private int maxScroll() {
        return Math.max(0, filtered.size() - ROWS);
    }

    private void updateFilter() {
        String q = sSearch.trim().toLowerCase(Locale.ROOT);
        filtered = new ArrayList<>();
        for (String s : allStructures) {
            if (q.isEmpty() || s.contains(q)) filtered.add(s);
        }
        listScroll = Mth.clamp(listScroll, 0, maxScroll());
    }

    @Override
    protected void init() {
        saveTexts();
        entries.clear();
        if (px < 0) {
            px = (width - W) / 2;
            py = (height - H) / 2;
        }
        clampPos();
        allStructures = Locator.structureNames();

        // ===== вкладки (видны всегда) =====
        String[] tabNames = {"Hacks", "Bot", "Find", "Keys"};
        for (int i = 0; i < 4; i++) {
            final int pg = i;
            tabs[i] = put(btn(44, 14, tabNames[i], b -> setPage(pg)), 6 + i * 46, 18, ALL);
        }

        // ===== Hacks =====
        flyBtn = put(btn(112, 18, "", b -> { Modules.toggleFly(); refresh(); }), 6, 38, P_HACKS);
        flyKey = put(btn(60, 18, "", b -> listen(ModEvents.FLY)), 124, 38, P_HACKS);
        put(btn(20, 18, "-", b -> Modules.adjustFly(-0.1)), 6, 58, P_HACKS);
        put(btn(20, 18, "+", b -> Modules.adjustFly(0.1)), 164, 58, P_HACKS);

        espBtn = put(btn(112, 18, "", b -> { Modules.toggleEsp(); refresh(); }), 6, 78, P_HACKS);
        espKey = put(btn(60, 18, "", b -> listen(ModEvents.ESP)), 124, 78, P_HACKS);

        boatBtn = put(btn(112, 18, "", b -> { Modules.toggleBoat(); refresh(); }), 6, 98, P_HACKS);
        boatKey = put(btn(60, 18, "", b -> listen(ModEvents.BOAT)), 124, 98, P_HACKS);
        put(btn(20, 18, "-", b -> Modules.adjustBoat(-0.1)), 6, 118, P_HACKS);
        put(btn(20, 18, "+", b -> Modules.adjustBoat(0.1)), 164, 118, P_HACKS);

        xrayBtn = put(btn(112, 18, "", b -> { Modules.toggleXray(); refresh(); }), 6, 138, P_HACKS);
        xrayKey = put(btn(60, 18, "", b -> listen(ModEvents.XRAY)), 124, 138, P_HACKS);
        put(btn(20, 18, "-", b -> Xray.adjustRange(-4)), 6, 158, P_HACKS);
        put(btn(20, 18, "+", b -> Xray.adjustRange(4)), 164, 158, P_HACKS);

        autoBtn = put(btn(112, 18, "", b -> { AutoMine.toggle(); refresh(); }), 6, 178, P_HACKS);
        autoKey = put(btn(60, 18, "", b -> listen(ModEvents.AUTOMINE)), 124, 178, P_HACKS);

        nightBtn = put(btn(112, 18, "", b -> { Modules.toggleNight(); refresh(); }), 6, 198, P_HACKS);
        nightKey = put(btn(60, 18, "", b -> listen(ModEvents.NIGHT)), 124, 198, P_HACKS);

        for (int i = 0; i < Xray.ORES.length; i++) {
            final Xray.Ore ore = Xray.ORES[i];
            int col = i % 3, row = i / 3;
            oreBtns[i] = put(btn(58, 14, "", b -> {
                ore.enabled = !ore.enabled;
                Xray.markDirty();
                refresh();
            }), 6 + col * 60, 232 + row * 16, P_HACKS);
        }

        // ===== Bot =====
        xBox = put(box(56, sX, 9, true), 6, 48, P_BOT);
        yBox = put(box(56, sY, 5, true), 67, 48, P_BOT);
        zBox = put(box(56, sZ, 9, true), 128, 48, P_BOT);

        put(btn(56, 16, "My pos", b -> {
            LocalPlayer p = minecraft.player;
            if (p != null) {
                xBox.setValue(Integer.toString(p.getBlockX()));
                zBox.setValue(Integer.toString(p.getBlockZ()));
                yBox.setValue("");
            }
        }), 6, 68, P_BOT);
        put(btn(56, 16, "Walk", b -> {
            Integer x = parseInt(xBox);
            Integer z = parseInt(zBox);
            Integer y = parseInt(yBox);
            if (x == null || z == null) {
                Modules.say("[CheatLab] Enter X and Z (Y is optional).");
                return;
            }
            saveTexts();
            onClose();
            GoTo.startSurface(x, z, y);
        }), 67, 68, P_BOT);
        put(btn(56, 16, "Stop all", b -> {
            Modules.stopAll();
            Modules.say("[CheatLab] Stopped.");
        }), 128, 68, P_BOT);

        gatherKindBtn = put(btn(88, 16, "", b -> {
            gatherIdx = (gatherIdx + 1) % Gatherer.Kind.values().length;
            refresh();
        }), 6, 104, P_BOT);
        amountBox = put(box(40, sAmount, 3, true), 98, 104, P_BOT);
        gRadiusBox = put(box(40, sGRadius, 2, true), 142, 104, P_BOT);
        put(btn(88, 16, "Start gather", b -> {
            Gatherer.Kind k = Gatherer.Kind.values()[gatherIdx];
            Integer a = parseInt(amountBox);
            Integer r = parseInt(gRadiusBox);
            int amount = a == null || a <= 0 ? (k == Gatherer.Kind.FOOD ? 4 : 16) : Math.min(a, 512);
            int radius = r == null ? 32 : Math.max(8, Math.min(64, r));
            saveTexts();
            onClose();
            Gatherer.start(k, amount, radius, false);
        }), 6, 124, P_BOT);
        put(btn(88, 16, "Stop", b -> {
            Modules.stopAll();
            Modules.say("[CheatLab] Stopped.");
        }), 98, 124, P_BOT);

        eatBtn = put(btn(88, 16, "", b -> { Modules.toggleAutoEat(); refresh(); }), 6, 150, P_BOT);
        forageBtn = put(btn(88, 16, "", b -> { Modules.toggleAutoForage(); refresh(); }), 98, 150, P_BOT);

        // ===== Find =====
        updateFilterSilently();
        searchBox = put(box(178, sSearch, 24, false), 6, 48, P_FIND);
        searchBox.setResponder(s -> {
            sSearch = s;
            updateFilter();
        });
        put(btn(14, 14, "^", b -> listScroll = Math.max(0, listScroll - 3)), 170, LIST_Y, P_FIND);
        put(btn(14, 14, "v", b -> listScroll = Math.min(maxScroll(), listScroll + 3)), 170, LIST_Y + ROWS * ROWH - 14, P_FIND);
        findRadiusBox = put(box(56, sFindRadius, 4, true), 6, 170, P_FIND);
        findBtn = put(btn(116, 16, "", b -> {
            Integer r = parseInt(findRadiusBox);
            int radius = r == null ? 1000 : Math.max(16, Math.min(3200, r));
            saveTexts();
            String filter = selectedStructure != null ? selectedStructure : searchBox.getValue().trim();
            Locator.locate(radius, filter);
        }), 66, 170, P_FIND);

        // ===== Keys =====
        KeyMapping[] maps = keyMaps();
        for (int i = 0; i < maps.length; i++) {
            final KeyMapping m = maps[i];
            keyBtns[i] = put(btn(74, 18, "", b -> listen(m)), 110, 38 + i * 22, P_KEYS);
        }

        updateFilter();
        applyPage();
        refresh();
    }

    private void updateFilterSilently() {
        updateFilter();
    }

    private void applyPage() {
        for (Entry e : entries) {
            boolean show = e.page() == ALL || e.page() == page;
            e.w().visible = show;
            e.w().active = show;
        }
    }

    private void listen(KeyMapping m) {
        listening = m;
        refresh();
    }

    private Component keyLabel(KeyMapping m) {
        return listening == m ? Component.literal("> ? <") : m.getTranslatedKeyMessage();
    }

    private static String onOff(boolean v) {
        return v ? "ON" : "OFF";
    }

    private void refresh() {
        String[] tabNames = {"Hacks", "Bot", "Find", "Keys"};
        for (int i = 0; i < tabs.length; i++) {
            tabs[i].setMessage(Component.literal(tabNames[i])
                    .withStyle(i == page ? ChatFormatting.YELLOW : ChatFormatting.WHITE));
        }
        flyBtn.setMessage(Component.literal("Fly: " + onOff(Modules.fly)));
        espBtn.setMessage(Component.literal("Player ESP: " + onOff(Modules.esp)));
        boatBtn.setMessage(Component.literal("Boat Fly: " + onOff(Modules.boatFly)));
        xrayBtn.setMessage(Component.literal("X-Ray: " + onOff(Xray.enabled)));
        autoBtn.setMessage(Component.literal("Auto-mine: " + onOff(AutoMine.enabled)));
        nightBtn.setMessage(Component.literal("Night vision: " + onOff(Modules.night)));
        flyKey.setMessage(keyLabel(ModEvents.FLY));
        espKey.setMessage(keyLabel(ModEvents.ESP));
        boatKey.setMessage(keyLabel(ModEvents.BOAT));
        xrayKey.setMessage(keyLabel(ModEvents.XRAY));
        autoKey.setMessage(keyLabel(ModEvents.AUTOMINE));
        nightKey.setMessage(keyLabel(ModEvents.NIGHT));
        for (int i = 0; i < Xray.ORES.length; i++) {
            Xray.Ore o = Xray.ORES[i];
            oreBtns[i].setMessage(Component.literal(o.name)
                    .withStyle(o.enabled ? ChatFormatting.GREEN : ChatFormatting.GRAY));
        }
        gatherKindBtn.setMessage(Component.literal("Gather: " + Gatherer.Kind.values()[gatherIdx].label));
        eatBtn.setMessage(Component.literal("Eat: " + onOff(Modules.autoEat)));
        forageBtn.setMessage(Component.literal("Forage: " + onOff(Modules.autoForage)));
        String sel = selectedStructure;
        if (sel != null) {
            String shown = sel.length() > 14 ? sel.substring(0, 14) : sel;
            findBtn.setMessage(Component.literal("Find: " + shown));
        } else {
            findBtn.setMessage(Component.literal("Find (typed text)"));
        }
        KeyMapping[] maps = keyMaps();
        for (int i = 0; i < maps.length; i++) {
            keyBtns[i].setMessage(keyLabel(maps[i]));
        }
    }

    private void clampPos() {
        px = Mth.clamp(px, 0, Math.max(0, width - W));
        py = Mth.clamp(py, 0, Math.max(0, height - H));
    }

    private void reposition() {
        for (Entry e : entries) {
            e.w().setX(px + e.dx());
            e.w().setY(py + e.dy());
        }
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partial) {
        g.fill(px, py, px + W, py + H, 0xE0101018);
        g.fill(px, py, px + W, py + 16, 0xFF2D5BFF);
        g.renderOutline(px, py, W, H, 0xFF2D5BFF);
        g.drawString(font, "CheatLab  (drag the blue bar)", px + 6, py + 4, 0xFFFFFF);

        if (page == P_HACKS) {
            g.drawCenteredString(font, String.format(Locale.ROOT, "Fly speed: %.1f", Modules.flySpeed), px + W / 2, py + 63, 0xFFFFFF);
            g.drawCenteredString(font, String.format(Locale.ROOT, "Boat speed: %.1f", Modules.boatSpeed), px + W / 2, py + 123, 0xFFFFFF);
            g.drawCenteredString(font, "X-Ray range: " + Xray.range, px + W / 2, py + 163, 0xFFFFFF);
            g.drawString(font, "Ores to find (click):", px + 6, py + 220, 0xFFFFFF);
            g.drawString(font, "/cheatlab = all commands", px + 6, py + 300, 0xAAAAAA);
        } else if (page == P_BOT) {
            g.drawString(font, "Run to:   X          Y (optional)   Z", px + 6, py + 38, 0xFFFFFF);
            g.drawString(font, "Gather:  what / amount / radius", px + 6, py + 92, 0xFFFFFF);
            LocalPlayer p = minecraft.player;
            int y = 176;
            if (p != null) {
                String w = GoTo.statusLine(p);
                String ga = Gatherer.statusLine();
                if (w != null) {
                    g.drawString(font, w, px + 6, py + y, 0x55FF55);
                    y += 11;
                }
                if (ga != null) {
                    g.drawString(font, ga, px + 6, py + y, 0x55FF55);
                    y += 11;
                }
                if (w == null && ga == null) g.drawString(font, "Bot idle", px + 6, py + y, 0xAAAAAA);
            }
            g.drawString(font, "Hungry with no food while running:", px + 6, py + 214, 0xAAAAAA);
            g.drawString(font, "the bot pauses, hunts/harvests food,", px + 6, py + 224, 0xAAAAAA);
            g.drawString(font, "eats, then continues the route.", px + 6, py + 234, 0xAAAAAA);
            g.drawString(font, "Y filled: it digs to that height", px + 6, py + 250, 0xAAAAAA);
            g.drawString(font, "after arriving (hold a pickaxe).", px + 6, py + 260, 0xAAAAAA);
        } else if (page == P_FIND) {
            g.drawString(font, "Search (type letters) - click to select:", px + 6, py + 38, 0xFFFFFF);
            int lx = px + LIST_X, ly = py + LIST_Y;
            g.fill(lx, ly, lx + LIST_W, ly + ROWS * ROWH, 0x66000000);
            for (int i = 0; i < ROWS; i++) {
                int idx = listScroll + i;
                if (idx >= filtered.size()) break;
                String name = filtered.get(idx);
                int ry = ly + i * ROWH;
                boolean hover = mouseX >= lx && mouseX < lx + LIST_W && mouseY >= ry && mouseY < ry + ROWH;
                if (name.equals(selectedStructure)) g.fill(lx, ry, lx + LIST_W, ry + ROWH, 0x883355FF);
                else if (hover) g.fill(lx, ry, lx + LIST_W, ry + ROWH, 0x33FFFFFF);
                g.drawString(font, font.plainSubstrByWidth(name, LIST_W - 4), lx + 3, ry + 2,
                        name.equals(selectedStructure) ? 0xFFFF55 : 0xFFFFFF);
            }
            if (filtered.isEmpty()) g.drawString(font, "no match", lx + 3, ly + 3, 0xAAAAAA);
            g.drawString(font, "Radius (blocks):", px + 6, py + 158, 0xAAAAAA);

            g.drawString(font, Locator.searching ? "Searching..." : "Results (click = copy x z to Bot):", px + 6, py + 192, 0xFFFFFF);
            List<Locator.Found> res = Locator.results;
            for (int i = 0; i < RES_ROWS && i < res.size(); i++) {
                Locator.Found f = res.get(i);
                String line = f.name() + " ~" + f.x() + " " + f.z() + " (" + f.dist() + ")";
                int ry = py + RES_Y + i * RES_H;
                boolean hover = mouseX >= px + 6 && mouseX < px + W - 6 && mouseY >= ry && mouseY < ry + RES_H;
                if (hover) g.fill(px + 6, ry, px + W - 6, ry + RES_H, 0x33FFFFFF);
                g.drawString(font, font.plainSubstrByWidth(line, W - 16), px + 8, ry + 1, 0x55FF55);
            }
            if (res.isEmpty() && !Locator.searching) {
                g.drawString(font, "Singleplayer only.", px + 8, py + RES_Y + 1, 0xAAAAAA);
            }
        } else {
            for (int i = 0; i < KEY_LABELS.length; i++) {
                g.drawString(font, KEY_LABELS[i], px + 8, py + 38 + i * 22 + 5, 0xFFFFFF);
            }
            int y = 38 + KEY_LABELS.length * 22 + 6;
            g.drawString(font, "Click a key box, then press a key", px + 6, py + y, 0xAAAAAA);
            g.drawString(font, "ESC = cancel", px + 6, py + y + 10, 0xAAAAAA);
        }

        super.render(g, mouseX, mouseY, partial);
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        if (listening != null) {
            listening = null;
            refresh();
            return true;
        }
        if (button == 0 && mx >= px && mx <= px + W && my >= py && my <= py + 16) {
            dragging = true;
            dragDX = (int) mx - px;
            dragDY = (int) my - py;
            return true;
        }
        if (page == P_FIND && button == 0) {
            int lx = px + LIST_X, ly = py + LIST_Y;
            if (mx >= lx && mx < lx + LIST_W && my >= ly && my < ly + ROWS * ROWH) {
                int i = listScroll + (int) ((my - ly) / ROWH);
                if (i >= 0 && i < filtered.size()) {
                    String s = filtered.get(i);
                    selectedStructure = s.equals(selectedStructure) ? null : s;
                    refresh();
                }
                return true;
            }
            int ry = py + RES_Y;
            if (mx >= px + 6 && mx < px + W - 6 && my >= ry && my < ry + RES_ROWS * RES_H) {
                List<Locator.Found> res = Locator.results;
                int i = (int) ((my - ry) / RES_H);
                if (i >= 0 && i < res.size()) {
                    Locator.Found f = res.get(i);
                    xBox.setValue(Integer.toString(f.x()));
                    zBox.setValue(Integer.toString(f.z()));
                    yBox.setValue("");
                    saveTexts();
                    setPage(P_BOT);
                }
                return true;
            }
        }
        return super.mouseClicked(mx, my, button);
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double delta) {
        if (page == P_FIND) {
            int lx = px + LIST_X, ly = py + LIST_Y;
            if (mx >= lx && mx < lx + LIST_W && my >= ly && my < ly + ROWS * ROWH) {
                listScroll = Mth.clamp(listScroll - (int) Math.signum(delta) * 2, 0, maxScroll());
                return true;
            }
        }
        return super.mouseScrolled(mx, my, delta);
    }

    @Override
    public boolean mouseDragged(double mx, double my, int button, double dx, double dy) {
        if (dragging) {
            px = Mth.clamp((int) mx - dragDX, 0, Math.max(0, width - W));
            py = Mth.clamp((int) my - dragDY, 0, Math.max(0, height - H));
            reposition();
            return true;
        }
        return super.mouseDragged(mx, my, button, dx, dy);
    }

    @Override
    public boolean mouseReleased(double mx, double my, int button) {
        dragging = false;
        return super.mouseReleased(mx, my, button);
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (listening != null) {
            if (keyCode != GLFW.GLFW_KEY_ESCAPE) {
                listening.setKey(InputConstants.Type.KEYSYM.getOrCreate(keyCode));
                KeyMapping.resetMapping();
                minecraft.options.save();
            }
            listening = null;
            refresh();
            return true;
        }
        boolean typing = getFocused() instanceof EditBox;
        if (!typing && ModEvents.MENU.matches(keyCode, scanCode)) {
            onClose();
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override
    public void removed() {
        saveTexts();
        super.removed();
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }
}
