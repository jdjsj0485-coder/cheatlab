package com.example.cheatlab;

import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.core.BlockPos;
import net.minecraft.tags.FluidTags;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.phys.Vec3;

import java.util.ArrayList;
import java.util.List;

/**
 * /cheatlab walk x z: бот идёт по поверхности к точке. Океаны обходит, а если обойти нельзя,
 * плывёт по поверхности (голова над водой, без урона). Путь пересчитывается по ходу.
 */
public final class GoTo {
    private static boolean running;
    private static int gx, gz;
    private static BlockPos goal;
    private static List<BlockPos> path = new ArrayList<>();
    private static int idx;
    private static int sinceProgress;
    private static int replans;
    private static boolean swimNoticeShown;

    private GoTo() {}

    public static boolean active() { return running; }

    public static BlockPos goal() { return running ? goal : null; }

    public static List<BlockPos> renderPath() {
        if (!running) return List.of();
        return path;
    }

    public static void startSurface(int x, int z) {
        Minecraft mc = Minecraft.getInstance();
        LocalPlayer p = mc.player;
        if (p == null || mc.level == null) return;
        if (Modules.fly) {
            Modules.say("[CheatLab] Turn Fly off first.");
            return;
        }
        if (AutoMine.enabled) AutoMine.stop("[CheatLab] Auto-mine stopped.");
        gx = x;
        gz = z;
        running = true;
        replans = 0;
        swimNoticeShown = false;
        path = new ArrayList<>();
        Modules.say("[CheatLab] Walking to " + x + " " + z + ". Red line = route. Stop: /cheatlab stop");
        plan(mc, p);
    }

    public static void stop(String message) {
        boolean was = running;
        running = false;
        goal = null;
        path = new ArrayList<>();
        idx = 0;
        Minecraft mc = Minecraft.getInstance();
        if (mc.options != null) {
            mc.options.keyUp.setDown(false);
            mc.options.keyJump.setDown(false);
        }
        if (was && message != null) Modules.say(message);
    }

    private static double endDistance(List<BlockPos> nodes) {
        if (nodes.isEmpty() || goal == null) return Double.MAX_VALUE;
        return Pathfinder.h(nodes.get(nodes.size() - 1), goal);
    }

    private static void plan(Minecraft mc, LocalPlayer p) {
        Level level = mc.level;
        BlockPos start = p.blockPosition();

        // высота цели: поверхность, если чанк загружен
        BlockPos probe = new BlockPos(gx, start.getY(), gz);
        int gy = level.hasChunkAt(probe)
                ? level.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, gx, gz)
                : start.getY();
        goal = new BlockPos(gx, gy, gz);

        Pathfinder.Result r = Pathfinder.find(level, start, goal, false);
        boolean swimUsed = false;
        if (!r.complete()) {
            Pathfinder.Result r2 = Pathfinder.find(level, start, goal, true);
            if (r2.complete() || endDistance(r2.nodes()) < endDistance(r.nodes()) - 0.5) {
                r = r2;
                swimUsed = true;
            }
        }

        idx = 1; // узел 0 - текущая клетка
        sinceProgress = 0;
        path = new ArrayList<>(r.nodes());

        if (r.nodes().size() <= 1) {
            if (reached(start)) {
                stop("[CheatLab] Arrived.");
            } else {
                int left = (int) Math.round(Pathfinder.h(start, goal));
                stop("[CheatLab] No further path (about " + left + " blocks left): a wall, lava, a cliff or unloaded terrain.");
            }
            return;
        }
        if (swimUsed && !swimNoticeShown) {
            swimNoticeShown = true;
            Modules.say("[CheatLab] Water in the way: will swim on the surface (head above water).");
        }
        if (!r.complete() && replans == 0) {
            Modules.say("[CheatLab] Full route not known yet, moving to the closest safe point and re-planning.");
        }
    }

    private static boolean reached(BlockPos feet) {
        return goal != null
                && Math.abs(feet.getX() - goal.getX()) + Math.abs(feet.getZ() - goal.getZ()) <= 1
                && Math.abs(feet.getY() - goal.getY()) <= 2;
    }

    private static boolean nodeReached(Level level, BlockPos feet, BlockPos node, boolean swimming) {
        if (feet.equals(node)) return true;
        boolean nodeWater = level.getFluidState(node).is(FluidTags.WATER);
        if (swimming || nodeWater) {
            return feet.getX() == node.getX() && feet.getZ() == node.getZ() && Math.abs(feet.getY() - node.getY()) <= 1;
        }
        return false;
    }

    public static void tick(Minecraft mc, LocalPlayer p) {
        if (!running) return;
        if (mc.level == null) return;
        Level level = mc.level;
        if (mc.screen != null) {
            mc.options.keyUp.setDown(false);
            mc.options.keyJump.setDown(false);
            return;
        }
        if (Modules.fly || p.isPassenger()) {
            stop("[CheatLab] Walk stopped (Fly or vehicle).");
            return;
        }
        if (p.getHealth() < 6.0f) {
            stop("[CheatLab] Walk stopped: low health.");
            return;
        }

        BlockPos feet = p.blockPosition();
        if (reached(feet)) {
            stop("[CheatLab] Arrived.");
            return;
        }

        if (idx >= path.size()) {
            if (++replans > 80) {
                stop("[CheatLab] Walk gave up after too many re-plans.");
                return;
            }
            plan(mc, p);
            return;
        }

        boolean swimming = p.isInWater();
        BlockPos next = path.get(idx);
        if (nodeReached(level, feet, next, swimming)) {
            idx++;
            sinceProgress = 0;
            return;
        }
        for (int j = idx + 1; j < Math.min(path.size(), idx + 4); j++) {
            if (nodeReached(level, feet, path.get(j), swimming)) {
                idx = j + 1;
                sinceProgress = 0;
                return;
            }
        }
        if (feet.distSqr(next) > 25 || ++sinceProgress > 100) {
            if (++replans > 80) {
                stop("[CheatLab] Walk gave up (stuck).");
                return;
            }
            plan(mc, p);
            return;
        }

        Vec3 want = Vec3.atBottomCenterOf(next);
        double dx = want.x - p.getX();
        double dz = want.z - p.getZ();
        double hd = Math.sqrt(dx * dx + dz * dz);
        if (hd > 0.08) {
            p.setYRot((float) Math.toDegrees(Math.atan2(-dx, dz)));
        }
        mc.options.keyUp.setDown(hd > 0.2);
        boolean jump;
        if (swimming) {
            jump = true; // держим пробел: всплываем и плывём с головой над водой
        } else {
            jump = p.onGround() && (next.getY() > feet.getY() || (p.horizontalCollision && hd > 0.3));
        }
        mc.options.keyJump.setDown(jump);
    }
}
