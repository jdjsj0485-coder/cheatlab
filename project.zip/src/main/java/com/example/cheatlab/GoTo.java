package com.example.cheatlab;

import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

import java.util.ArrayList;
import java.util.List;

/** Бот идёт к координатам: /cheatlab goto x y z. Путь строит Pathfinder и пересчитывает по ходу. */
public final class GoTo {
    private static BlockPos goal;
    private static List<BlockPos> path = new ArrayList<>();
    private static int idx;
    private static int sinceProgress;
    private static int replans;

    private GoTo() {}

    public static boolean active() { return goal != null; }

    public static BlockPos goal() { return goal; }

    public static List<BlockPos> renderPath() {
        if (goal == null) return List.of();
        return path;
    }

    public static void start(int x, int y, int z) {
        Minecraft mc = Minecraft.getInstance();
        LocalPlayer p = mc.player;
        if (p == null || mc.level == null) return;
        if (Modules.fly) {
            Modules.say("[CheatLab] Turn Fly off first.");
            return;
        }
        if (AutoMine.enabled) AutoMine.stop("[CheatLab] Auto-mine stopped.");
        goal = new BlockPos(x, y, z);
        replans = 0;
        sinceProgress = 0;
        Modules.say("[CheatLab] Going to " + x + " " + y + " " + z + ". Stop: /cheatlab stop");
        plan(mc, p);
    }

    public static void stop(String message) {
        boolean was = goal != null;
        goal = null;
        path = new ArrayList<>();
        idx = 0;
        Minecraft mc = Minecraft.getInstance();
        if (mc.options != null) {
            mc.options.keyUp.setDown(false);
            mc.options.keyJump.setDown(false);
        }
        if (was && message != null) Modules.say(message);
    }

    private static void plan(Minecraft mc, LocalPlayer p) {
        Level level = mc.level;
        Pathfinder.Result r = Pathfinder.find(level, p.blockPosition(), goal);
        idx = 1; // узел 0 - это текущая клетка
        sinceProgress = 0;
        if (r.nodes().size() <= 1) {
            path = new ArrayList<>(r.nodes());
            if (reached(p.blockPosition())) {
                stop("[CheatLab] Arrived.");
            } else {
                int left = Math.abs(p.blockPosition().getX() - goal.getX())
                        + Math.abs(p.blockPosition().getZ() - goal.getZ())
                        + Math.abs(p.blockPosition().getY() - goal.getY());
                stop("[CheatLab] No further path (about " + left + " blocks left). Blocked by water, lava, a wall or unloaded terrain.");
            }
            return;
        }
        path = new ArrayList<>(r.nodes());
        if (!r.complete() && replans == 0) {
            Modules.say("[CheatLab] Full route not known yet, moving to the closest safe point and re-planning.");
        }
    }

    private static boolean reached(BlockPos feet) {
        return Math.abs(feet.getX() - goal.getX()) + Math.abs(feet.getZ() - goal.getZ()) <= 1
                && Math.abs(feet.getY() - goal.getY()) <= 2;
    }

    public static void tick(Minecraft mc, LocalPlayer p) {
        if (goal == null) return;
        if (mc.level == null) return;
        if (mc.screen != null) {
            mc.options.keyUp.setDown(false);
            mc.options.keyJump.setDown(false);
            return;
        }
        if (Modules.fly || p.isPassenger()) {
            stop("[CheatLab] Go-to stopped (Fly or vehicle).");
            return;
        }
        if (p.getHealth() < 6.0f) {
            stop("[CheatLab] Go-to stopped: low health.");
            return;
        }

        BlockPos feet = p.blockPosition();
        if (reached(feet)) {
            stop("[CheatLab] Arrived.");
            return;
        }

        if (idx >= path.size()) {
            if (++replans > 60) {
                stop("[CheatLab] Go-to gave up after too many re-plans.");
                return;
            }
            plan(mc, p);
            return;
        }

        BlockPos next = path.get(idx);
        if (feet.equals(next)) {
            idx++;
            sinceProgress = 0;
            return;
        }
        // уже стоим на одном из следующих узлов
        for (int j = idx + 1; j < Math.min(path.size(), idx + 4); j++) {
            if (feet.equals(path.get(j))) {
                idx = j + 1;
                sinceProgress = 0;
                return;
            }
        }
        // сбились с маршрута или застряли
        if (feet.distSqr(next) > 25 || ++sinceProgress > 100) {
            if (++replans > 60) {
                stop("[CheatLab] Go-to gave up (stuck).");
                return;
            }
            plan(mc, p);
            return;
        }

        Vec3 want = Vec3.atBottomCenterOf(next);
        double dx = want.x - p.getX();
        double dz = want.z - p.getZ();
        double hd = Math.sqrt(dx * dx + dz * dz);
        if (hd > 0.08) {
            p.setYRot((float) Math.toDegrees(Math.atan2(-dx, dz)));
        }
        mc.options.keyUp.setDown(hd > 0.2);
        boolean jump = p.onGround() && (next.getY() > feet.getY() || (p.horizontalCollision && hd > 0.3));
        mc.options.keyJump.setDown(jump);
    }
}
