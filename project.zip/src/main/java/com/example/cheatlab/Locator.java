package com.example.cheatlab;

import com.mojang.datafixers.util.Pair;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.client.server.IntegratedServer;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Holder;
import net.minecraft.core.HolderSet;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.levelgen.structure.Structure;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;

/**
 * Локатор структур: /cheatlab locate <радиус> [часть названия].
 * Работает в одиночной игре (спрашивает локальный сервер мира, как команда /locate).
 */
public final class Locator {
    private record Found(String name, int x, int z, int dist) {}

    private Locator() {}

    public static void locate(int radiusBlocks, String filter) {
        Minecraft mc = Minecraft.getInstance();
        LocalPlayer p = mc.player;
        if (p == null || mc.level == null) return;
        IntegratedServer server = mc.getSingleplayerServer();
        if (server == null) {
            Modules.say("[CheatLab] Structure search works in singleplayer only (it asks the local world server). On a remote server it is not possible.");
            return;
        }
        final BlockPos center = p.blockPosition();
        final int chunks = Math.max(1, Math.min(200, radiusBlocks / 16));
        final ResourceKey<Level> dim = mc.level.dimension();
        final String flt = filter == null ? "" : filter.toLowerCase(Locale.ROOT);

        Modules.say("[CheatLab] Searching structures within ~" + radiusBlocks + " blocks. The game may freeze for a few seconds...");

        server.execute(() -> {
            List<Found> found = new ArrayList<>();
            try {
                ServerLevel sl = server.getLevel(dim);
                if (sl == null) {
                    mc.execute(() -> Modules.say("[CheatLab] World not available."));
                    return;
                }
                Registry<Structure> reg = sl.registryAccess().registryOrThrow(Registries.STRUCTURE);
                for (Holder.Reference<Structure> ref : reg.holders().toList()) {
                    ResourceLocation id = ref.key().location();
                    if (!flt.isEmpty() && !id.getPath().contains(flt)) continue;
                    Pair<BlockPos, Holder<Structure>> res = sl.getChunkSource().getGenerator()
                            .findNearestMapStructure(sl, HolderSet.direct(List.of(ref)), center, chunks, false);
                    if (res == null) continue;
                    BlockPos pos = res.getFirst();
                    int dx = pos.getX() - center.getX();
                    int dz = pos.getZ() - center.getZ();
                    int dist = (int) Math.sqrt((double) dx * dx + (double) dz * dz);
                    if (dist > radiusBlocks) continue;
                    found.add(new Found(id.getPath(), pos.getX(), pos.getZ(), dist));
                }
            } catch (Throwable t) {
                mc.execute(() -> Modules.error("locate", t));
                return;
            }
            found.sort(Comparator.comparingInt(Found::dist));
            mc.execute(() -> {
                if (found.isEmpty()) {
                    Modules.say("[CheatLab] No structures found in that radius.");
                    return;
                }
                Modules.say("[CheatLab] Found (approximate x z, distance). Use /cheatlab walk x z:");
                int n = Math.min(found.size(), 15);
                for (int i = 0; i < n; i++) {
                    Found f = found.get(i);
                    Modules.say("  " + f.name() + ": ~" + f.x() + " " + f.z() + "  (" + f.dist() + " blocks)");
                }
            });
        });
    }
}
