package com.example.cheatlab;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.PauseScreen;
import net.minecraft.client.gui.screens.inventory.InventoryScreen;
import net.minecraft.network.chat.Component;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.ScreenEvent;
import net.minecraftforge.eventbus.api.EventPriority;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.function.BooleanSupplier;

@Mod.EventBusSubscriber(modid = CheatLab.MODID, bus = Mod.EventBusSubscriber.Bus.FORGE, value = Dist.CLIENT)
public class ScreenHooks {

    private static Component label(String name, boolean on) {
        return Component.literal(name + ": " + (on ? "ON" : "OFF"));
    }

    private static Button toggle(String name, int x, int y, BooleanSupplier state, Runnable action) {
        return Button.builder(label(name, state.getAsBoolean()), b -> {
            action.run();
            b.setMessage(label(name, state.getAsBoolean()));
        }).bounds(x, y, 92, 16).build();
    }

    @SubscribeEvent(priority = EventPriority.LOWEST)
    public static void onInit(ScreenEvent.Init.Post e) {
        try {
            // Escape: кнопка CheatLab. Если другой мод подменил меню паузы, меню открывается клавишей Right Shift.
            if (e.getScreen() instanceof PauseScreen) {
                e.addListener(Button.builder(Component.literal("CheatLab"),
                        b -> Minecraft.getInstance().setScreen(new CheatMenuScreen()))
                        .bounds(6, 6, 90, 20).build());
            }
            // Инвентарь (E): кнопка меню и быстрые переключатели слева
            if (e.getScreen() instanceof InventoryScreen) {
                int x = 4, y = 4;
                e.addListener(Button.builder(Component.literal("CheatLab menu"),
                        b -> Minecraft.getInstance().setScreen(new CheatMenuScreen()))
                        .bounds(x, y, 92, 18).build());
                y += 20;
                e.addListener(toggle("Fly", x, y, () -> Modules.fly, Modules::toggleFly));
                y += 18;
                e.addListener(toggle("ESP", x, y, () -> Modules.esp, Modules::toggleEsp));
                y += 18;
                e.addListener(toggle("X-Ray", x, y, () -> Xray.enabled, Modules::toggleXray));
                y += 18;
                e.addListener(toggle("Night", x, y, () -> Modules.night, Modules::toggleNight));
                y += 18;
                e.addListener(toggle("Boat Fly", x, y, () -> Modules.boatFly, Modules::toggleBoat));
                y += 18;
                e.addListener(toggle("Auto-eat", x, y, () -> Modules.autoEat, Modules::toggleAutoEat));
            }
        } catch (Throwable t) {
            Modules.error("screen-buttons", t);
        }
    }
}
